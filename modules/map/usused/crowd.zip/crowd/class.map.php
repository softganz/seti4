<?php
/**
 * map class for map networks mapping with crowd sourcing
 *
 * @package map
 * @version 0.30.0
 * @copyright Copyright (c) 2000-present , The SoftGanz Group By Panumas Nontapan
 * @author Panumas Nontapan <webmaster@softganz.com> , http://www.softganz.com
 * @created 2012-10-05
 * @modify 2016-01-28
 * ============================================
 * This program is free software. You can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License.
 * ============================================
 */

menu('map/shape','Mapping Application Shape Page','map.shape','__controller',2,true,'static','home');
menu('map/help','Mapping Application Help Page','map.help','__controller',2,true,'static','home');
menu('map/report','Mapping Application Report Page','map.report','__controller',2,true,'static','home');
menu('map','Mapping Application Main Page','map','__controller',1,true,'static','home');

cfg('map.version','0.30.0');
cfg('map.release','16.1.28');

class map extends module {

	public function __construct() {
		parent::__construct();
		cfg('page_class','apps');
		cfg('page_id','app-map');
		$this->theme->title='แผนที่เครือข่าย';
	}

	function permission() { return 'administer maps,create maps,edit own maps content,access maps,access full maps';}

	/**
	 * Method _home
	 * Home page of package gis
	 *
	 * @return String
	 */

	public function _home($mapGroup=1) {
		//		$ret.=print_o($_SERVER,'$_SERVER');
		$para=para(func_get_args(),'loc=7.060,100.468,15');
		$mapGroup=get_first($mapGroup,1);

		$is_api=false;
		if ($_SERVER["HTTP_REFERER"]) {
			preg_match('/hatyaicityclimate/i',$_SERVER["HTTP_REFERER"],$out);
			if (!$out) {
				$is_api=true;
			}
		}

		$mapRs=mydb::select('SELECT * FROM %map_name% WHERE `'.(is_numeric($mapGroup)?'mapgroup':'mapalias').'`=:mapgroup LIMIT 1',':mapgroup',$mapGroup);
		if ($mapRs->_empty) return message('error','ไม่มีแผนที่ตามระบุ ('.$mapGroup.')');
		$mapGroup=$mapRs->mapgroup;

		head('<meta property="og:title" content="'.$mapRs->mapname.'" />
		<meta property="og:type" content="website" />
		<meta property="og:url" content="'.cfg('domain').'/map" />
		<meta property="og:image" content="'.cfg('domain').'/upload/pics/crowdmap.jpg" />
		<meta property="og:description" content="คราวด์ซอร์สซิง คือ การที่มวลชนหรือคนจำนวนมากในเครือข่ายอินเตอร์เน็ตมาช่วยกันทำงานบางอย่างโดยไม่จำกัดจำนวนคนที่มาเข้าร่วม แต่ละคนจะใช้เวลาว่างเพียงเล็กน้อยมาช่วยกันเติมเต็มข้อมูลที่ตนเองรู้
		แผนที่เครือข่าย คือ ข้อมูลที่บอกว่าใคร ทำอะไรหรือเกี่ยวข้องอย่างไร อยู่ที่ไหน กับเรื่องดังกล่าว ในที่นี้ก็คือบุคคล/หน่วยงาน/องค์กร/ฯลฯ ที่มีส่วนเกี่ยวข้อง
		หลักการในการช่วยกันทำข้อมูล คือ การใช้เวลาเพียงเล็กน้อยเข้ามาช่วยกันป้อนข้อมูลที่ประกอบด้วย ชื่อบุคคล/องค์กร/หน่วยงาน/ฯลฯ ภาระกิจ และที่อยู่ ที่ท่านรู้จักหรือได้รับทราบ (หากสามารถระบุพิกัดในแผนที่ได้ก็จะดีมาก ๆ) ใน Facebook Page และจะนำผลของการศึกษารวมทั้งแผนที่เครือข่ายไปเป็นฐานข้อมูลและแสดงผลไว้ในเว็บไซท์ '.cfg('domain').' ต่อไป
		ท่านสนใจจะเข้าร่วมในการทำข้อมูลแผนที่เครือข่ายหรือไม่?" />
		');

		$this->theme->title=$mapRs->mapname;

		cfg_db('crowdsourcing.map.mapping.hits',cfg_db('crowdsourcing.map.mapping.hits')+1);
		/*
		$ret.='<header><h2>'.$mapRs->mapname.'</h2></header>';
		$ret.='<form method="get" id="mapSearch" class="search-box" action="'.url('map/searchwho').'" role="search"><label for="fq">ค้นหา</label><input class="form-text" maxlength="100" accesskey="/" id="fq" name="fq" autocomplete="off" tabindex="" value="" title="พิมพ์ชื่อเพื่อค้นหา" type="text" placeholder="ค้นหาบุคคล หน่วยงาน สถานที่"><button type="submit" title="Search"><span class="hidden_elem">Search</span></button></form>';
		*/
		$ret.='<div class="nav-box" id="map-nav">';
		$ui=new ui();
		$ui->add('<a href="'.url().'" data-action="refresh">'.tr('Home','หน้าหลัก').'</a>');
		$ui->add('<form method="get" id="mapSearch" class="search-box" action="'.url('map/searchwho').'" role="search"><label for="fq">ค้นหา</label><input class="form-text" maxlength="100" accesskey="/" id="fq" name="fq" autocomplete="off" tabindex="" value="" title="พิมพ์ชื่อเพื่อค้นหา" type="text" placeholder="ค้นหาบุคคล หน่วยงาน สถานที่"><button type="submit" title="Search"><span class="hidden_elem">Search</span></button></form>');
		$ui->add('<a href="javascript:void(0)" id="getMyLocation">'.tr('My Location','ตำแหน่งปัจจุบัน').'</a>');
		$ui->add('<a href="'.url('map'.($mapGroup!=1?'/'.$mapGroup:'')).'" data-action="refresh">'.tr('Map','แผนที่').'</a>');
		//		$ui->add('<a href="javascript:void(0)">'.tr('Upload Photo','ส่งภาพถ่าย').'</a>');
		$ui->add('<a href="'.url('map/list').'">'.tr('List','รายการ').'</a>');
		$ui->add('<a href="'.url('map/menu').'">'.tr('Menu','เมนู').'</a>');
		$ui->add('<a href="'.url('user').'">'.(i()->ok?i()->name:tr('Member','สมาชิก')).'</a>');
		$ui->add('<a href="'.url('map/help').'">'.tr('Help','ช่วยเหลือ').'</a>');
		$ui->add('<a href="https://www.facebook.com/CrowdsourcingDisasterNetworksMapping" title="พูดคุย เสนอแนะ แจ้งข่าว แจ้งข้อมูล ได้ที่ เฟสบุ๊ค แผนที่เครือข่ายเฝ้าระวังและช่วยเหลือผู้ประสพภัยพิบัติ" target="_blank" data-action="refresh">'.tr('Facebook','Facebook').'</a>');
		//		$ui->add('<a href="javascript:void(0)">'.tr('Setting','ตั้งค่า').'</a>');
		$ret.=$ui->show('ul');
		$ret.='</div>';
		$ret.='<div id="map-box"></div>'._NL;

		if ($_REQUEST['id']) {
			$stmt='SELECT m.*, CONCAT(X(`latlng`),",",Y(`latlng`)) latlng, X(`latlng`) lat, Y(`latlng`) lnt
							FROM %map_networks% m
							WHERE mapid=:mapid LIMIT 1';
			$rs=mydb::select($stmt,':mapid',$_REQUEST['id']);
		}

		$ret.='<div class="app-output">'._NL;
		$ret.='<div id="map_canvas" width="100%" height="100%" data-group="'.$mapGroup.'" data-center="'.get_first($rs->latlng,$mapRs->center).'" data-zoom="'.($rs->latlng?16:$mapRs->zoom).'" data-layer="'.get_first($_REQUEST['layer'],'All').'" data-url="'.url('map/layer').'" data-addurl="'.url('map/add').'" data-mapname="'.$mapRs->mapname.'">กำลังโหลดแผนที่!!!!</div>'._NL;
		$ret.='</div>'._NL;
		$ret.='<div class="app-footer">สถิติ <strong id="map-hits">'.cfg_db('crowdsourcing.map.mapping.hits').'</strong> hits จำนวนข้อมูล <strong id="map-totals">'.mydb::select('SELECT COUNT(*) total FROM %map_networks% LIMIT 1')->total.'</strong> รายการ</div>'._NL;

		head('googlemap','<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?language=th&key='.cfg('gmapkey').'"></script>');
		head('gmaps.js','<script type="text/javascript" src="/library/gmaps.js"></script>');
		head('map.js','<script type="text/javascript" src="map/js.map.js"></script>');
		head('jquery.form.js','<script type="text/javascript" src="/library/js/jquery.form.js"></script>');
		return $ret;
	}

	function _edit() {return $this->_add();}

	function _add() {
		$mapID=$_REQUEST['id'];
		$mapGroup=get_first($_REQUEST['gr'],$_REQUEST['mapgroup']);

		$ret='<a href="javascript:void(0)" class="icon-button close" data-action="add-cancel" data-id="'.$mapID.'" title="ยกเลิก คำเตือน : ข้อมูลที่ยังไม่บันทึกจะสูญหาย">X</a>';

		if (!user_access('create maps')) {
			$ret.=message('error','access denied');
			return $ret;
		}

		if ($mapID) {
			$stmt='SELECT m.*, CONCAT(X(`latlng`),",",Y(`latlng`)) latlng, X(`latlng`) lat, Y(`latlng`) lnt
							FROM %map_networks% m
							WHERE mapid=:mapid LIMIT 1';
			$rs=mydb::select($stmt,':mapid',$mapID);
			if ($rs->mapgroup) $mapGroup=$rs->mapgroup;
		}

		if ($mapGroup) {
			$mapGroupRs=mydb::select('SELECT * FROM %map_name% WHERE `mapgroup`=:mapgroup LIMIT 1',':mapgroup',$mapGroup);
		}

		$ret.='<h3>'.$mapGroupRs->mapname.'</h3>';
		//$this->theme->title='แผนที่เครือข่ายเฝ้าระวังและช่วยเหลือผู้ประสพภัยพิบัติ จังหวัดสงขลา รุ่นทดสอบ 1';

		$form->config->variable='mapping';
		$form->config->method='post';
		$form->config->action=url('map/update');

		$form->mapgroup->type='hidden';
		$form->mapgroup->value=get_first($mapGroup,$rs->mapgroup);

		$form->mapid->type='hidden';
		$form->mapid->value=$rs->mapid;

		$form->village->type='hidden';
		$form->village->value=$rs->village;

		$form->tambon->type='hidden';
		$form->tambon->value=$rs->tambon;

		$form->ampur->type='hidden';
		$form->ampur->value=$rs->ampur;

		$form->changwat->type='hidden';
		$form->changwat->value=$rs->changwat;

		$form->frame_1='<fieldset id="map-info'.(empty($rs->mapid) ? '-add' : '').'"><legend>ข้อมูลแผนที่</legend>';

		$form->who->type='text';
		$form->who->label=get_first($mapGroupRs->title_who,cfg('map-who'),'ใคร - Who ?');
		$form->who->placeholder='ระบุชื่อคน,องค์กร,หน่วยงาน';
		$form->who->value=htmlspecialchars($rs->who);
		$form->who->autocomplete="off";

		$form->dowhat->type='text';
		$form->dowhat->label=get_first($mapGroupRs->title_dowhat,cfg('map-dowhat'),'ทำอะไร - Do what ?');
		$form->dowhat->placeholder='เช่น แจกอาหาร,ที่จอดรถ';
		$form->dowhat->value=htmlspecialchars($rs->dowhat);

		$form->when->type='checkbox';
		$form->when->label='เมื่อไหร่ - When ?';
		$form->when->options=array('prepare'=>'ก่อนเกิดเหตุ','during'=>'ระหว่างเกิดเหตุ','after'=>'หลังเกิดเหตุ');
		$form->when->display='inline';
		$form->when->multiple=true;
		if ($rs->prepare) $form->when->value[]='prepare';
		if ($rs->during) $form->when->value[]='during';
		if ($rs->after) $form->when->value[]='after';

		$form->address->type='text';
		$form->address->label=get_first($mapGroupRs->title_where,cfg('map-address'),'อยู่ที่ไหน - Where ?');
		$form->address->placeholder='ระบุที่อยู่ ตำบล อำเภอ จังหวัด โทรศัพท์';
		$form->address->value=htmlspecialchars($rs->address);

		$form->latlng->type='text';
		$form->latlng->label='พิกัด - GIS ?';
		$form->latlng->placeholder='ระบุพิกัดหรือคลิกบนแผนที่แล้วลากหมุดเพื่อย้ายตำแหน่ง';
		$form->latlng->value=htmlspecialchars($rs->latlng);
		$form->latlng->description='คำแนะนำ:ป้อน <strong>ใคร-Who?</strong> ก่อนแล้วจะสามารถคลิกวางหมุดบนแผนที่ได้';

		$form->submit->type='submit';
		$form->submit->items->save='บันทึก'.($rs->mapid?'การแก้ไข':'');
		$form->submit->posttext.='หรือ <a data-action="add-cancel" data-id="'.$mapID.'" href="'.url('map').'" title="ยกเลิก คำเตือน : ข้อมูลที่ยังไม่บันทึกจะสูญหาย">ยกเลิก</a>';

		$form->detail->type='textarea';
		$form->detail->label='รายละเอียดเพิ่มเติม - More detail ?';
		$form->detail->rows=2;
		$form->detail->cols=10;
		$form->detail->placeholder='รายละเอียดเพิ่มเติม';
		$form->detail->value=htmlspecialchars($rs->detail);

		$form->privacy->type='radio';
		$form->privacy->label='ความเป็นส่วนตัว - Privacy';
		$form->privacy->options['private']='ให้ฉันเห็นเพียงคนเดียว';
		$form->privacy->options['group']='ให้มองเห็นเฉพาะในกลุ่ม';
		$form->privacy->options['public']='ให้ทุกคนมองเห็นได้';
		$form->privacy->display='inline';
		$form->privacy->value=get_first($rs->privacy,'public');
		$form->frame_2='</fieldset>';

		if (empty($rs->mapid)) {
			$form->frame_3='<fieldset id="map-poster"><legend>รายละเอียดของผู้ส่งข้อมูล</legend>';
			$form->poster->type='text';
			$form->poster->label='ชื่อผู้ส่งข้อมูล - Poster ?';
			$form->poster->placeholder='ระบุชื่อผู้ส่งข้อมูล';
			$form->poster->value=htmlspecialchars($rs->poster);
			$form->poster->description='คำแนะนำ:ป้อน <strong>รายละเอียดของผู้ส่งข้อมูล</strong> จะถูกเก็บไว้เป็นความลับ ไม่มีการเผยแพร่ผ่านเว็บไซท์ มีไว้สำหรับการประสานงานกลับในกรณีที่ต้องการทราบข้อมูลเพิ่มเติมเท่านั้น';

			$form->email->type='text';
			$form->email->label='อีเมล์ - E-Mail ?';
			$form->email->placeholder='name@example.com';
			$form->email->value=htmlspecialchars($rs->email);

			$form->phone->type='text';
			$form->phone->label='โทรศัพท์ - Phone ?';
			$form->phone->placeholder='xxx xxx xxxx';
			$form->phone->value=htmlspecialchars($rs->phone);
			$form->frame_4='</fieldset>';
		}

		$ret .= theme('form','map-edit',$form);

		$ret.='<script type="text/javascript"><!--
		$(document).ready(function() {
			if ($("#edit-mapping-mapid").val()!="") {
				addEnable=false;
				var mapID=$("#edit-mapping-mapid").val();
				map.removeMarker(markers[mapID]);
				marker=gis.markers[mapID];
				addMarker=map.addMarker({
					lat: marker.lat,
					lng: marker.lng,
					draggable: true,
					dragend: function(e) { $("#edit-mapping-latlng").val(e.latLng.lat()+","+e.latLng.lng()); },
				});
			}
		});
		</script>';
		return $ret;
	}

	function _list() {
		$mapGroup=get_first($_REQUEST['gr'],$_REQUEST['mapgroup']);
		$ret='<a href="javascript:void(0)" class="close" data-action="box-close" title="ปิดหน้าต่าง">X</a>';
		if ($_REQUEST['o']=='new') $order='`mapid` DESC';
		else $order='CONVERT (`who` USING tis620) ASC';
		$stmt='SELECT m.*,
									CONCAT(X(`latlng`),",",Y(`latlng`)) latlng, X(`latlng`) lat, Y(`latlng`) lnt
					FROM %map_networks% m
					WHERE `mapgroup` IN (:mapgroup)
					ORDER BY '.$order;

		$dbs=mydb::select($stmt,':mapgroup', $mapGroup);
		$tables->class='item';
		$icons['prepare']='/library/img/geo/prepare.png';
		$icons['during']='/library/img/geo/during.png';
		$icons['after']='/library/img/geo/after.png';
		$icons['place']='/library/img/geo/risk-1-1.png';
		$icons['หมู่บ้าน']='/library/img/geo/risk-2.png';
		$icons['cctv']='/library/img/geo/webcam.jpg';
		$icons['none']='/library/img/geo/none.png';
		foreach ($dbs->items as $irs) {
			if ($irs->latlng && $irs->mapid!=$rs->mapid) {
				if (preg_match('/CCTV/',$irs->dowhat)) $icon=$icons['cctv'];
				else if (preg_match('/เครือข่ายเตือนภัย/',$irs->dowhat)) $icon=$icons['เครือข่ายเตือนภัย'];
				else if (preg_match('/หมู่บ้าน/',$irs->dowhat)) $icon=$icons['หมู่บ้าน'];
				else if (preg_match('/สถานที่/',$irs->dowhat)) $icon=$icons['place'];
				else if ($irs->prepare) $icon=$icons['prepare'];
				else if ($irs->during) $icon=$icons['during'];
				else if ($irs->after) $icon=$icons['after'];
				else $icon=$icons['none'];
				unset($where);
				if ($irs->prepare) $where[]='ก่อนเกิดเหตุ';
				if ($irs->during) $where[]='ระหว่างเกิดเหตุ';
				if ($irs->after) $where[]='หลังเกิดเหตุ';
				$gis['markers'][]=array('lat'=>$irs->lat,
															'lng'=>$irs->lnt,
															'title'=>$irs->who,
															'icon'=>$icon,
															'content'=>'<h4>'.$irs->who.'</h4><p><a class="sg-action" data-rel="#main" href="'.url('map','id='.$irs->mapid).'">แก้ไข</a></p><p>ทำอะไร : '.$irs->dowhat.'<br />เมื่อไหร่ : '.implode(',',$where).'<br />ที่ไหน : '.$irs->address.'</p>'
															);
			}
			$info='<a href="'.url('map','id='.$irs->mapid).'" data-action="showmap" data-id="'.$irs->mapid.'" data-who="'.$irs->who.'">'.$irs->who.'</a><p>'.$irs->dowhat.'</p>';
			$tables->rows[]=array($info);
			$items[]=$info;
		}
		//		$ret.=theme('table',$tables);
		$ret.='<ul class="map-list"><li>'.implode('</li><li>',$items).'</li></ul>';
		return $ret;
	}

	/**
	 * Save map
	 *
	 * @param Array $_POST
	 * @return String
	 */
	function _update() {
		$ret['html']='Update';
		$post=(object)post('mapping');
		if ($post->who) {
			$post->mapgroup=get_first($post->mapgroup,1);
			$post->dowhat=rtrim(trim($post->dowhat),',');
			$post->created=date('U');
			$post->uid=get_first(i()->uid,'func.NULL');
			$post->prepare=$post->when['prepare']?'Yes':NULL;
			$post->during=$post->when['during']?'Yes':NULL;
			$post->after=$post->when['after']?'Yes':NULL;
			$post->village=get_first($post->village,'');
			$post->tambon=get_first($post->tambon,'');
			$post->ampur=get_first($post->ampur,'');
			$post->changwat=get_first($post->changwat,'');
			$post->ip=ip2long(GetEnv('REMOTE_ADDR'));
			if (!$post->status) $post->status=cfg('map-default-status');

			if ($post->latlng) {
				list($x,$y)=explode(',',$post->latlng);
				if (is_numeric($x) && is_numeric($y)) {
					$post->point='func.PointFromText("POINT('.$x.' '.$y.')")';
				}
			} else {
				$post->latlngPoint=NULL;
			}

			if (preg_match('/(.*)(หมู่|หมู่ที่|ม\.)([0-9\s]+)\s+(.*)/',$post->address,$out) || preg_match('/(.*)(ตำบล|ต\.)(.*)/',$post->address,$out)) {
				$post->village=(in_array($out[2],array('หมู่','หมู่ที่','ม.')) && is_numeric($out[3])) ? $out[3] : $post->village;
			}

			if ($post->mapid) {
				$stmt='SELECT m.*, CONCAT(X(`latlng`),",",Y(`latlng`)) latlng, X(`latlng`) lat, Y(`latlng`) lnt
						FROM %map_networks% m
						WHERE m.mapid=:mapid
						LIMIT 1';
				$rs=mydb::select($stmt,':mapid',$post->mapid);
				$is_edit=user_access('administer maps','edit own maps content',$rs->uid);
				if ($rs->status=='lock' && !$is_edit) {
					$ret['html']=message('error','access denied');
					$ret['id']=$rs->mapid;
					$ret['marker']=$this->_getwho($rs->mapid);
					$ret['msg']='Cancel';
					return $ret;
				}
			}

			$stmt='INSERT INTO %map_networks%
							(`mapid`, `mapgroup`, `uid`, `status`, `who`, `dowhat`, `prepare`, `during`, `after`, `address`, `village`, `tambon`, `ampur`, `changwat`, `detail`, `privacy`, `latlng`, '.($post->mapid ? '' : '`poster`, `email`, `phone`, ').'`ip`, `created`, `modified`)
						VALUES
							(:mapid, :mapgroup, :uid, :status, :who, :dowhat, :prepare, :during, :after, :address, :village, :tambon, :ampur, :changwat, :detail, :privacy, :point, '.($post->mapid ? '' : ':poster, :email, :phone, ').':ip, :created, NULL)
						 ON DUPLICATE KEY UPDATE `mapgroup`=:mapgroup, `who`=:who, `dowhat`=:dowhat, `prepare`=:prepare, `during`=:during, `after`=:after, `address`=:address,`village`=:village, `tambon`=:tambon, `ampur`=:ampur, `changwat`=:changwat, `detail`=:detail, `privacy`=:privacy, `latlng`=:point, `modified`=:created
							';
			mydb::query($stmt,$post);
			$debug.=mydb()->_query.'<br />'.mydb()->_errmsg.'<br />'.print_o($post,'$post');
			//			$ret['html'].=$debug;

			// Update modify history
			if ($post->mapid) {
				$ret['html'].=print_o($rs,'$rs');
				$fieldChecks=array('gid','who','dowhat','prepare','during','after','address','vilage','tambon','ampur','changwat','detail','privacy','latlng');
				$modify->mapid=$post->mapid;
				$modify->uid=i()->uid;
				foreach ($fieldChecks as $fld) {
					if ($rs->{$fld}!=$post->{$fld}) {
						$modify->fld=$fld;
						$modify->from=$rs->{$fld}?$rs->{$fld}:'';
						$modify->to=$post->{$fld}?$post->{$fld}:'';
						mydb::query('INSERT INTO %map_history% (`mapid`, `uid`, `fld`, `from`, `to`) VALUES (:mapid, :uid, :fld, :from, :to)',$modify);
						//						$ret['html'].=mydb()->_query.print_o($modify,'$modify');
					}
				}
			}

			$ret['id']=$mapid=$post->mapid?$post->mapid:mydb()->insert_id;

			$ret['marker']=$this->_getwho($mapid);
			$ret['msg']='Updated';
			//			$debug.='ID='.$mapid.'<br />'.print_o($post,'$post');
		}
		//		$ret['location']=array('map','id='.$mapid,NULL);
		return $ret;
	}

	/**
	 * Search from farm name
	 *
	 * @param String $q or $_GET['q'] or $_POST['q'] : Substring in name
	 * @param Integer $n or $_GET['n'] or $_POST['n'] : Item for result
	 * @param Integer $p or $_GET['p'] or $_POST['p'] : Page for result
	 * @return json[{value:org_id, label:org_name},...]
	 */
	function _getwho($id=NULL) {
		if (is_object($id)) {
			$rs=$id;
		} else {
			$id=trim(get_first($id,$_REQUEST['id']));
			if (empty($id)) return '[]';
			$stmt='SELECT m.*, u.name, CONCAT(X(`latlng`),",",Y(`latlng`)) latlng, X(`latlng`) lat, Y(`latlng`) lnt
						FROM %map_networks% m
							LEFT JOIN %users% u USING(uid)
						WHERE m.mapid=:mapid
						LIMIT 1';
			$rs=mydb::select($stmt,':mapid',$id);
		}

		$icons['prepare']='/library/img/geo/pin-prepare.png';
		$icons['during']='/library/img/geo/pin-during.png';
		$icons['after']='/library/img/geo/pin-after.png';
		$icons['place']='/library/img/geo/pin-place.png';
		$icons['city']='/library/img/geo/pin-city.png';
		$icons['cctv']='/library/img/geo/pin-camera.png';
		$icons['none']='/library/img/geo/pin-none.png';
		$icons['บ้าน']='/library/img/geo/pin-home.png';
		$icons['network']='/library/img/geo/pin-man.png';
		$icons['staffgauge']='/library/img/geo/pin-staffgauge.png';
		$icons['flag']='/library/img/geo/pin-flag.png';
		$icons['green']='/library/img/geo/pin-greenfood.png';
		$icons['forrest']='/library/img/geo/pin-forrest.png';
		$icons['rice']='/library/img/geo/pin-greenrice.png';

		if (preg_match('/CCTV/i',$rs->dowhat)) $icon=$icons['cctv'];
		else if (preg_match('/สวนผัก/',$rs->dowhat)) $icon=$icons['green'];
		else if (preg_match('/ข้าว/',$rs->dowhat)) $icon=$icons['rice'];
		else if (preg_match('/บุกรุกป่า/',$rs->dowhat)) $icon=$icons['forrest'];
		else if (preg_match('/ธงเตือนภัย/',$rs->dowhat)) $icon=$icons['flag'];
		else if (preg_match('/Staff gauge/i',$rs->dowhat)) $icon=$icons['staffgauge'];
		else if (preg_match('/เครือข่ายเตือนภัย/',$rs->dowhat)) $icon=$icons['network'];
		else if (preg_match('/หมู่บ้าน/',$rs->dowhat)) $icon=$icons['city'];
		else if (preg_match('/บ้าน/',$rs->dowhat)) {
		//			if (!user_access('access full maps')) return array();
			$icon=$icons['บ้าน'];
		} else if (preg_match('/สถานที่/',$rs->dowhat)) $icon=$icons['place'];
		else if ($rs->prepare) $icon=$icons['prepare'];
		else if ($rs->during) $icon=$icons['during'];
		else if ($rs->after) $icon=$icons['after'];
		else $icon=$icons['none'];
		unset($where);

		if ($rs->prepare) $where[]='ก่อนเกิดเหตุ';
		if ($rs->during) $where[]='ระหว่างเกิดเหตุ';
		if ($rs->after) $where[]='หลังเกิดเหตุ';

		$is_edit=user_access('administer maps','edit own maps content',$rs->uid);

		$html='<div class="map-info map__info"><h4>'.$rs->who.'</h4>';
		$ui=new ui();
		if (empty($rs->status) || ($rs->status=='lock' && $is_edit)) $ui->add('<a class="sg-action" data-rel="map-box" href="'.url('map/add','id='.$rs->mapid).'">แก้ไข</a>');
		if ($is_edit) $ui->add('<a class="sg-action" href="'.url('map/delete','id='.$rs->mapid).'" data-confirm="ต้องการลบหมุด กรุณายืนยัน?" data-rel="this" data-removeparent="div">ลบ</a>');
		if ($is_edit) $ui->add('<a href="'.url('map/lock/'.$rs->mapid).'" data-action="lock">'.($rs->status=='lock'?'Locked':'Unlocked').'</a>');
		$ui->add('<a rel="map-box" href="'.url('map/history','id='.$rs->mapid).'" title="ประวัติการแก้ไขข้อมูล">ประวัติ</a>');
		$html.='<p>'.$ui->show().'</p>';
		$html.='<p>ทำอะไร : '.$rs->dowhat.($where?'<br />เมื่อไหร่ : '.implode(',',$where):'').'<br />ที่ไหน : '.$rs->address.'</p><div class="map__info--detail">'.sg_text2html($rs->detail).'</div>';

		$html.='<div class="photo">'._NL;
		$html.='<ul class="photo">'._NL;
		if (debug('method')) $html.=$rs->photos.print_o($rs,'$rs');
		if ($rs->gallery) {
			$doc='';
			$photos=mydb::select('SELECT f.fid, f.type, f.file, f.title FROM %topic_files% f WHERE f.gallery=:gallery',':gallery',$rs->gallery);
			$ui=new ui();
			foreach ($photos->items as $item) {
				list($photoid,$photo)=explode('|',$item);
				if ($item->type=='photo') {
					$photo=model::get_photo_property($item->file);
					$photo_alt=$item->title;
					$html .= '<li>';
					//					$html.='<a href="#" onclick="ajax.viewimage(\''.$photo->_src.'\','.$photo->_size->width.','.$photo->_size->height.');return false;" title="Click to view full photo '.$photo_alt.'">';
					$html.='<a group="photo'.$rs->mapid.'" href="'.$photo->_src.'" title="'.htmlspecialchars($photo_alt).'">';
					$html.='<img class="photo photo-'.($photo->_size->width>$photo->_size->height?'wide':'tall').'" src="'.$photo->_src.'" height="60" alt="photo '.$photo_alt.'" ';
					$html.=' />';
					$html.='</a>';
					$photomenu=array();
					$ui->clear();
					if ($is_edit) {
						$ui->add('<a href="'.url('map/delphoto/'.$item->fid).'" data-action="delphoto" data-mapid="'.$rs->mapid.'" title="ลบภาพนี้">X</a>');
					}
					$html.=$ui->show();
					$html .= '</li>'._NL;
				} else if ($item->type=='doc') {
					$doc.='<li>';
					$doc.='<a href="'.cfg('paper.upload.document.url').$item->file.'" title="'.htmlspecialchars($photo_alt).'">';
					$doc.=$item->title;
					$doc.='</a>';
					$photomenu=array();
					$ui->clear();
					if ($is_edit) {
						$ui->add('[<a href="'.url('project/edit/delphoto/'.$item->fid).'" action="delphoto" title="ลบไฟล์นี้">ลบไฟล์</a>]');
					}
					$doc.=$ui->show();
					$doc.='</li>';
				}
			}
		}

		$html.='</ul>'._NL;
		if ($doc) $html.='<h3>ไฟล์ประกอบกิจกรรม</h3><ul class="doc">'.$doc.'</ul>';

		if (empty($rs->status) || ($rs->status=='lock' && $is_edit)) {
			$html.='<br clear="all" /><form method="post" enctype="multipart/form-data" action="'.url('map/sendphoto/'.$rs->mapid).'"><span class="btn btn-success fileinput-button"><i class="icon-plus icon-white"></i><span>ส่งภาพ</span><input type="file" name="photo" class="inline-upload" data-mapid="'.$rs->mapid.'" /></span></form>';
				//$html.='<div class="progress"><div class="bar"></div ><div class="percent">0%</div ></div>';
		}
		$html.='</div><!--photo-->'._NL;
		$html.='<p class="poster">โดย '.get_first($rs->name,'ไม่ระบุชื่อ').' เมื่อ '.sg_date($rs->created,'ว ดด ปปปป H:i').' น.';
		//$html.=print_o($rs,'$rs');
		$html.='</div>';

		$result=array('mapid'=>$rs->mapid,
													'lat'=>$rs->lat,
													'lng'=>$rs->lnt,
													'title'=>$rs->who,
													'icon'=>$icon,
													'dowhat'=>$rs->dowhat,
													'content'=>$html,
													);
		return $result;
	}

	/**
	 * Search from farm name
	 *
	 * @param String $q or $_GET['q'] or $_POST['q'] : Substring in name
	 * @param Integer $n or $_GET['n'] or $_POST['n'] : Item for result
	 * @param Integer $p or $_GET['p'] or $_POST['p'] : Page for result
	 * @return json[{value:org_id, label:org_name},...]
	 */
	function _searchwho($mapGroup=1,$q,$n,$p) {
		sendheader('text/html');
		$mapGroup=intval(get_first($_REQUEST['gr'],$_REQUEST['mapgroup']));
		$q=trim(get_first($q,$_GET['q'],$_POST['q']));
		$n=intval(get_first($item,$_GET['n'],$_POST['n'],20));
		$p=intval(get_first($p,$_GET['p'],$_POST['p'],1));
		if (empty($q)) return '[]';

		$stmt='SELECT *
						FROM %map_networks% m
						WHERE m.who LIKE :q
						ORDER BY m.`who` ASC
						LIMIT '.($p-1).','.$n;

		$stmt='SELECT m.*, CONCAT(X(`latlng`),",",Y(`latlng`)) latlng, X(`latlng`) lat, Y(`latlng`) lnt
					FROM %map_networks% m
					WHERE m.mapgroup=:mapgroup AND m.who LIKE :q
					ORDER BY CONVERT (`who` USING tis620) ASC;';
		$dbs=mydb::select($stmt,':mapgroup',$mapGroup, ':q','%'.$q.'%');

		$result=array();
		foreach ($dbs->items as $rs) {
			$desc=$rs->address;
			$result[] = array('value'=>$rs->mapid, 'label'=>htmlspecialchars($rs->who), 'desc'=>$desc);
		}
		if (debug('api')) {
			$result[]=array('value'=>'query','label'=>$dbs->_query);
			if ($dbs->_error) $result[]=array('value'=>'error','label'=>$dbs->_error_msg);
			$result[]=array('value'=>'num_rows','label'=>'Result is '.$dbs->_num_rows.' row(s).');
		}
		return json_encode($result);
	}

	/**
	 * Search from farm name
	 *
	 * @param String $q or $_GET['q'] or $_POST['q'] : Substring in name
	 * @param Integer $n or $_GET['n'] or $_POST['n'] : Item for result
	 * @param Integer $p or $_GET['p'] or $_POST['p'] : Page for result
	 * @return json[{value:org_id, label:org_name},...]
	 */
	function _searchdowhat($q,$n,$p) {
		sendheader('text/html');
		$q=get_first($q,trim($_REQUEST['q']));
		$n=intval(get_first($item,$_REQUEST['n'],20));
		$p=intval(get_first($p,$_REQUEST['p'],1));

		if (strpos($q,',')) {
			$q=trim(substr($q,strrpos($q,',')+1));
		}
		if (empty($q)) return '[]';

		$stmt='SELECT DISTINCT `dowhat`
						FROM %map_networks% m
						WHERE m.dowhat LIKE :q
						LIMIT '.($p-1).','.$n;
		$dbs=mydb::select($stmt,':q','%'.$q.'%');

		$result=array();
		$founds=array();
		foreach ($dbs->items as $rs) {
			foreach (explode(',',$rs->dowhat) as $str) {
				$str=trim($str);
				if (preg_match('/'.$q.'/i',$str) && !in_array($str,$founds)) $founds[]=$str;
			}
		}
		foreach ($founds as $str) $result[] = array('label'=>$str);
		if (debug('api')) {
			$result[]=array('value'=>'query','label'=>$dbs->_query);
			if ($dbs->_error) $result[]=array('value'=>'error','label'=>$dbs->_error_msg);
			$result[]=array('value'=>'num_rows','label'=>'Result is '.$dbs->_num_rows.' row(s).');
			$result[]=array('label',implode(',',$founds));
		}
		return json_encode($result);
	}

	/**
	* Show main menu
	*
	* @return String
	*/
	function _menu() {
		$mapGroup=get_first($_REQUEST['gr'],$_REQUEST['mapgroup']);
		$ret='<a href="javascript:void(0)" class="close" data-action="box-close" title="ปิดหน้าต่าง">X</a>';
		$ui=new ui();
		//		$ui->add('<a class="sg-action" href="'.url('map/layer',array('gr'=>$mapGroup)).'" data-rel="map-box">กลุ่มแผนที่</a>');
		$ui->add('<a href="#" data-action="clear-map">ล้างแผนที่</a>');
		$ui->add('<a class="sg-action" href="'.url('map/layer',array('gr'=>$mapGroup)).'" data-rel="map-box">เลือกชั้นของแผนที่</a>');
		$ui->add('<a class="sg-action" href="'.url('map/area',array('gr'=>$mapGroup)).'" data-rel="map-box">เลือกพื้นที่</a>');
		$ui->add('<a class="sg-action" href="'.url('map/list',array('gr'=>$mapGroup)).'" data-rel="map-box">รายชื่อทั้งหมด</a>');
		$ui->add('<a class="sg-action" href="'.url('map/list',array('gr'=>$mapGroup,'o'=>'new')).'" data-rel="map-box">รายชื่อมาใหม่</a>');
		$ret.='<nav><h3>เมนูหลัก</h3>'.$ui->show('ul').'</nav>';
		$ui=new ui();
		$ui->add('<a href="'.url('map/report/daily').'" target="_blank">จำนวนการปักหมุดในแต่ละวัน</a>');
		$ui->add('<a href="'.url('map/report/growth').'" target="_blank">จำนวนการเพิ่มขึ้นของหมุดในแต่ละวัน</a>');

		$ret.='<nav><h3>รายงาน</h3>'.$ui->show('ul').'</nav>';

		return $ret;
	}

	function _area() {
		$mapGroup=get_first($_REQUEST['gr'],$_REQUEST['mapgroup']);
		$ret['html'].='<h3>เลือกชั้นแผนที่</h3>';
		$ret['html'].='<a href="javascript:void(0)" class="close" data-action="box-close" title="ปิดหน้าต่าง">X</a>';

		$ret['html'].='<form id="user-add-zone" method="get" action="'.url('map/layer',array('gr'=>$mapGroup)).'"><input type="hidden" name="areacode" id="areacode" value="" /><label for="areaname">เลือกพื้นที่</label><input type="text" name="areaname" id="areaname" size="30" value="" class="form-text" size="20" placeholder="ระบุตำบล หรือ อำเภอ หรือ จังหวัด" /></form>';

		$dbs=mydb::select('SELECT DISTINCT `dowhat` FROM %map_networks% WHERE `mapgroup`=:mapgroup AND `dowhat`!="" ORDER BY `dowhat` ASC',':mapgroup',$mapGroup);
		$tags=array();
		foreach (explode(',',$dbs->lists->text) as $value) {
			$value=trim($value);
			if (!array_key_exists($tags, $value)) $tags[$value]='<a href="'.url('map',array('gr'=>$mapGroup,'layer'=>$value)).'">'.$value.'</a>';
		}
		ksort($tags);
		$ret['html'].='<ul><li>'.implode('</li><li>', $tags).'</li></ul>';

		$ret['html'].='
		<script type="text/javascript">
		$(document).ready(function() {
			$("#areaname")
			.autocomplete({
				source: function(request, response) {
					$.get(url+"db/api/tambon?q="+encodeURIComponent(request.term), function(data){
						response($.map(data, function(item){
						return {
							label: item.label,
							value: item.value
						}
						}))
					}, "json");
				},
				minLength: 2,
				dataType: "json",
				cache: false,
				select: function(event, ui) {
					this.value = ui.item.label;
		//			$("#areaname").value(ui.item.label);
					// Do something with id
					$("#areacode").val(ui.item.value);
					$(this).closest("form").submit();
					return false;
				}
			});
		});
		</script>';
		return $ret['html'];
	}

	function _layer() {
		$mapGroup=get_first($_REQUEST['gr'],$_REQUEST['mapgroup']);
		$layer=get_first($_REQUEST['ly'],$_REQUEST['layer']);
		if (empty($mapGroup)) {
			$ret['html'].='<h3>เลือกกลุ่มแผนที่</h3>';
			$ret['html'].='<a href="javascript:void(0)" class="close" data-action="box-close" title="ปิดหน้าต่าง">X</a>';
			$dbs=mydb::select('SELECT * FROM %map_name% ORDER BY `mapname` ASC');
			$ret['html'].='<ul>';
			foreach ($dbs->items as $value) {
				$ret['html'].='<li><a href="'.url('map/'.$value->mapgroup).'">'.$value->mapname.'</a></li>';
			}
			$ret['html'].='</ul>';
				return $ret['html'];
		} else if (empty($layer)) {
			$ret['html'].='<h3>เลือกชั้นแผนที่</h3>';
			$ret['html'].='<a href="javascript:void(0)" class="close" data-action="box-close" title="ปิดหน้าต่าง">X</a>';
			$ret['html'].='<a href="#" data-action="clear-map">ล้างแผนที่</a>';
			$dbs=mydb::select('SELECT DISTINCT `dowhat` FROM %map_networks% WHERE `mapgroup`=:mapgroup AND `dowhat`!="" ORDER BY CONVERT (`dowhat` USING tis620) ASC',':mapgroup',$mapGroup);
			$tags=array();
			foreach (explode(',',$dbs->lists->text) as $value) {
				$value=trim($value);
				if (!array_key_exists($tags, $value)) $tags[$value]='<a href="'.url('map/layer',array('gr'=>$mapGroup,'layer'=>$value)).'" data-action="load-layer">'.$value.'</a>';
			}
			ksort($tags);
			$ret['html'].='<ul><li>'.implode('</li><li>', $tags).'</li></ul>';
			return $ret['html'];
		}

		$where=array();
		$where=sg::add_condition($where,'`mapgroup` IN (:mapgroup) ','mapgroup',$mapGroup);
		if ($layer && $layer!="All" ) $where=sg::add_condition($where,'`dowhat` LIKE :layer','layer','%'.$layer.'%');
		if (!user_access('access full maps')) $where=sg::add_condition($where,'`privacy`="public"');

		$stmt='SELECT m.*, u.`name`,
									 CONCAT(X(`latlng`),",",Y(`latlng`)) latlng, X(`latlng`) lat, Y(`latlng`) lnt
					FROM %map_networks% m
						LEFT JOIN %users% u USING (uid)
					'.($where?'WHERE '.implode(' AND ',$where['cond']):'').'
					ORDER BY `mapid` DESC;';
		$dbs=mydb::select($stmt,$where['value']);

		$ret['markers']=array();
		foreach ($dbs->items as $rs) {
			if ($rs->latlng && $who=$this->_getwho($rs)) $ret['markers'][$rs->mapid]=$who;
		}
		return $ret;
	}

	/**
	 * Send photo
	 *
	 * @param Integer $mapid
	 * @return String
	 */
	function _sendphoto($mapid) {
		$is_new_gallery=false;
		$ret='';

		$rs=mydb::select('SELECT `mapid`,`gallery` FROM %map_networks% WHERE `mapid`=:mapid LIMIT 1',':mapid',$mapid);
		$gallery=$rs->gallery;
		if (empty($gallery)) {
			$gallery=mydb::select('SELECT MAX(gallery) lastgallery FROM %topic_files% LIMIT 1')->lastgallery+1;
			$is_new_gallery=true;
		}

		$photo=$_FILES['photo'];
		if (!is_uploaded_file($photo['tmp_name'])) die("Upload error : No upload file");

		$ext=strtolower(sg_file_extension($photo['name']));
		if (in_array($ext,array('jpg','jpeg'))) {
			// Upload photo
			$upload=new classFile($photo,cfg('paper.upload.photo.folder'),cfg('photo.file_type'));
			if (!$upload->valid_format()) die("Upload error : Invalid photo format");
			if (!$upload->valid_size(cfg('photo.max_file_size')*1024)) {
				sg_photo_resize($upload->upload->tmp_name,cfg('photo.resize.width'),NULL,NULL,true,cfg('photo.resize.quality'));
			}
			if ($upload->duplicate()) $upload->generate_nextfile();
			$photo_upload=$upload->filename;
			$pics_desc['type'] = 'photo';
			$pics_desc['title']=$rs->activityname;
		} else {
			// Upload file
			$pics_desc['type'] = 'doc';
			$pics_desc['title']=$photo['name'];
			$upload=new classFile($photo,cfg('paper.upload.document.folder'),cfg('topic.doc.file_ext'));
			if (!$upload->valid_extension()) die("Upload error : Invalid file format");
			if ($upload->duplicate()) $upload->generate_nextfile();
			$photo_upload=$upload->filename;
		}

		$pics_desc['tpid'] = 0;
		$pics_desc['cid'] = 0;
		$pics_desc['gallery'] = $gallery;
		$pics_desc['uid']=i()->ok?i()->uid:'func.NULL';
		$pics_desc['file']=$photo_upload;
		$pics_desc['timestamp']='func.NOW()';
		$pics_desc['ip'] = ip2long(GetEnv('REMOTE_ADDR'));

		if ($upload->copy()) {
			$stmt='INSERT INTO %topic_files% (`type`, `tpid`, `cid`, `gallery`, `uid`, `file`,`title`, `timestamp`, `ip`) VALUES (:type, :tpid, :cid, :gallery, :uid, :file, :title, :timestamp, :ip)';
			mydb::query($stmt,$pics_desc);
			if ($is_new_gallery) mydb::query('UPDATE %map_networks% SET gallery=:gallery WHERE `mapid`=:mapid LIMIT 1',':mapid',$mapid,':gallery',$gallery);
			if ($pics_desc['type']=='photo') {
				$photo=model::get_photo_property($upload->filename);
				$ret.='<img src="'.$photo->_url.'" height="60" alt="" />';
			} else {
				$ret.='อัพโหลดไฟล์เรียบร้อย';
			}
		} else {
			$ret.='Upload error : Cannot save upload file';
		}
		return $ret;
	}

	/**
	 * Delete photo
	 *
	 * @param Integer $fid - file id
	 * @return String
	 */
	function _delphoto($fid) {
		// delete photos
		$rs=mydb::select('SELECT f.*, tr.`mapid` FROM %topic_files% f LEFT JOIN %map_networks% tr ON tr.`gallery`=f.`gallery` WHERE f.`fid`='.$fid.' LIMIT 1',':fid',$fid);
		if ($rs->file) {
			if ($rs->type=='photo') {
				mydb::query('DELETE FROM %topic_files% WHERE fid='.$fid.' AND `type`="photo" LIMIT 1',':fid',$fid);
				$remain=mydb::select('SELECT COUNT(*) remain FROM %topic_files% WHERE gallery=:gallery LIMIT 1',':gallery',$rs->gallery)->remain;
				if ($remain==0) {
					mydb::query('UPDATE %map_networks% SET gallery=NULL WHERE mapid=:mapid LIMIT 1',':mapid',$rs->mapid);
				}
				$filename=cfg('folder.abs').cfg('upload_folder').'pics/'.$rs->file;
				if (file_exists($filename) and is_file($filename)) {
					$is_photo_inused=db_count('%topic_files%',' file="'.$rs->file.'" AND fid!='.$rs->fid);
					if (!$is_photo_inused) unlink($filename);
					$ret.=$is_photo_inused?'ภาพถูกใช้โดยคนอื่น':'ลบภาพเรียบร้อยแล้ว';
				}
				model::watch_log('project','remove photo','Photo id '.$rs->fid.' - '.$rs->file.' of activity '.$rs->trid.' was removed from project '.$rs->tpid.' by '.i()->name.'('.i()->uid.')');
			} else if ($rs->type=='doc') {
				mydb::query('DELETE FROM %topic_files% WHERE fid='.$fid.' AND `type`="doc" LIMIT 1',':fid',$fid);
				$remain=mydb::select('SELECT COUNT(*) remain FROM %topic_files% WHERE gallery=:gallery LIMIT 1',':gallery',$rs->gallery)->remain;
				if ($remain==0) {
					mydb::query('UPDATE %map_networks% SET gallery=NULL WHERE mapid=:mapid LIMIT 1',':mapid',$rs->mapid);
				}
				$filename=cfg('paper.upload.document.folder').$rs->file;
				if (file_exists($filename) and is_file($filename)) {
					unlink($filename);
				}
				model::watch_log('project','remove doc','File id '.$rs->fid.' - '.$rs->file.' of activity '.$rs->trid.' was removed from project '.$rs->tpid.' by '.i()->name.'('.i()->uid.')');
			}
		}
		return $ret;
	}

	/**
	* Delete pin
	* @param Integer $id
	* @param String
	*/
	function _delete($id) {
		$mapid=get_first($id,post('id'));

		$rs=mydb::select('SELECT * FROM %map_networks% WHERE `mapid`=:mapid LIMIT 1',':mapid',$mapid);
		if (empty($rs->mapid)) return 'Error';

		$is_edit=user_access('administer maps','edit own maps content',$rs->uid);
		if (!$is_edit) return 'ไม่มีสิทธิ์';

		$ret='ลบ';

		//$ret.=print_o($rs,'$rs');
		mydb::query('DELETE FROM %map_history% WHERE `mapid`=:mapid',':mapid',$mapid);

		// Delete photo
		if ($rs->gallery) {
			$photoDbs=mydb::select('SELECT * FROM %topic_files% WHERE `gallery`=:gallery',':gallery',$rs->gallery);
			foreach ($photoDbs->items as $photoRs) {
				$this->_delphoto($photoRs->fid);
			}
			//$ret.=print_o($photoDbs,'$photoDbs');
		}

		mydb::query('DELETE FROM %map_networks% WHERE `mapid`=:mapid',':mapid',$mapid);
		return $ret;
	}

	function _lock($mapid) {
		$rs=mydb::select('SELECT `status` FROM %map_networks% WHERE `mapid`=:mapid LIMIT 1',':mapid',$mapid);
		$newstatus=$rs->status=='lock' ? 'func.NULL' : 'lock';
			mydb::query('UPDATE %map_networks% SET `status`=:status WHERE `mapid`=:mapid LIMIT 1',':mapid',$mapid, ':status',$newstatus);
		$ret.=$newstatus=='lock'?'Locked':'Unlocked';
		return $ret;
	}

	function _new() {
		$mapGroup=intval(get_first($_REQUEST['gr'],$_REQUEST['mapgroup']));
		$ret['refreshTime']=$refreshtime=intval($_REQUEST['t']);
		$ret['time']=date('U');
		$ret['totals']=mydb::select('SELECT COUNT(*) totals FROM %map_networks% LIMIT 1')->totals;
		$ret['hits']=cfg_db('crowdsourcing.map.mapping.hits');

		$where=array();
		$where=sg::add_condition($where,'`mapgroup` IN (:mapgroup) ','mapgroup',$mapGroup);
		if (!user_access('access full maps')) $where=sg::add_condition($where,'`privacy`="public"');
		$where=sg::add_condition($where,'(`created`>:refreshtime OR `modified`>:refreshtime)','refreshtime',$refreshtime);

		$stmt='SELECT m.*, u.name,
									 CONCAT(X(`latlng`),",",Y(`latlng`)) latlng, X(`latlng`) lat, Y(`latlng`) lnt
					FROM %map_networks% m
						LEFT JOIN %users% u USING (uid)
					'.($where?'WHERE '.implode(' AND ',$where['cond']):'').'
					ORDER BY `mapid` DESC;';
		$dbs=mydb::select($stmt,$where['value']);
		if (debug('method')) $ret['html'].=print_o($dbs,'$dbs');

		$ret['count']=$dbs->_num_rows;
		$ret['markers']=array();
		foreach ($dbs->items as $rs) {
			if ($rs->latlng && $who=$this->_getwho($rs)) $ret['markers'][$rs->mapid]=$who;
		}

		return $ret;
	}

	function _history($id) {
		$id=trim(get_first($id,post('id')));
		$ret.='<h3>ประวัติการแก้ไข</h3>';
		$ret.='<a href="javascript:void(0)" class="close" data-action="box-close" title="ปิดหน้าต่าง">X</a>';
		$dbs=mydb::select('SELECT h.*, u.`name` FROM %map_history% h LEFT JOIN %users% u USING(`uid`) WHERE `mapid`=:mapid ORDER BY `modifydate` DESC',':mapid',$id);
		$fields=array('privacy'=>'ความเป็นส่วนตัว', 'status'=>'สถานะ', 'who'=>'ใคร', 'dowhat'=>'ทำอะไร', 'when'=>'เมื่อไหร่', 'address'=>'ที่อยู่', 'village'=>'หมู่ที่', 'tambon'=>'ตำบล', 'ampur'=>'อำเภอ', 'changwat'=>'จังหวัด', 'detail'=>'รายละเอียดเพิ่มเติม', 'latlng'=>'พิกัด', 'prepare'=>'ก่อนเกิดเหตุ', 'during'=>'ระหว่างเกิดเหตุ', 'after'=>'หลังเกิดเหตุ');
		$ret.='<ul class="map-list">';
		foreach ($dbs->items as $rs) {
			$ret.='<li>@'.$rs->modifydate.' โดย '.$rs->name.'<br />ฟิลด์ : '.$fields[$rs->fld].'<br />จาก : '.$rs->from.'<br />เป็น : '.$rs->to.'</li>';
		}
		$ret.='</ul>';
		return $ret;
	}
} // end of class map

/*
Upgrade
TRUNCATE TABLE sgz_map_networks;
ALTER TABLE `sgz_map_networks` DROP `patriarch` , DROP `parent` ;
ALTER TABLE `sgz_map_networks` ADD `gid` INT UNSIGNED NOT NULL AFTER `mapid` , ADD INDEX ( `gid` ) ;
ALTER TABLE `sgz_map_networks` ADD `detail` TEXT NOT NULL AFTER `address` ;
ALTER TABLE `sgz_map_networks` ADD `privacy` ENUM( 'private', 'public', 'group' ) NOT NULL DEFAULT 'private' AFTER `uid` , ADD INDEX ( `privacy` ) ;
ALTER TABLE `sgz_map_networks` ADD `village` CHAR( 2 ) NULL AFTER `address` ,
ADD `tambon` CHAR( 2 ) NULL AFTER `village` ,
ADD `ampur` CHAR( 2 ) NULL AFTER `tambon` ,
ADD `changwat` CHAR( 2 ) NULL AFTER `ampur` ,
ADD INDEX ( `village` , `tambon` , `ampur` , `changwat` ) ;
ALTER TABLE `sgz_map_networks` ADD `latlng` POINT NOT NULL AFTER `detail` , ADD INDEX ( `latlng` ) ;
INSERT INTO `sgz_map_networks` (SELECT NULL,1,`uid`,2,`who`,`dowhat`,`prepare`,`during`,`after`,`when`,`address`,'','','','90','',`latlng`, `gis`,`photo`,`ip`,`created`
FROM `sgz_map_networks_bak` m
LEFT JOIN `sgz_gis` USING(gis)
WHERE mapid IN (
			SELECT MAX(mapid)
			FROM `sgz_map_networks_bak`
			GROUP BY IFNULL(patriarch,mapid)
		))
ORDER BY `mapid` ASC
*/
?>