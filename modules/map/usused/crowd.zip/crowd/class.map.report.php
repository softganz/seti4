<?php
/**
 * map help class for map networks mapping with crowd sourcing help
 *
 * @package map
 * @version 0.10
 * @copyright Copyright (c) 2000-present , The SoftGanz Group By Panumas Nontapan
 * @author Panumas Nontapan <webmaster@softganz.com> , http://www.softganz.com
 * @created 2013-09-05
 * @modify 2013-09-05
 * ============================================
 * This program is free software. You can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License.
 * ============================================
 */

class map_report extends module {

	public function __construct() {
		parent::__construct();
	}

	/**
	 * Method _home
	 * Home page of package gis
	 *
	 * @return String
	 */

	public function _home() {
		$ret='<a href="javascript:void(0)" class="close" data-action="box-close" title="ปิดหน้าต่าง">X</a>';
		$ret.='<h2>รายงาน</h2>';
		$ret.='<ul><li><a href="'.url('map/report/daily').'">จำนวนการปักหมุดในแต่ละวัน</a></li>
<li><a href="'.url('map/report/growth').'">จำนวนการเพิ่มขึ้นของหมุดในแต่ละวัน</a></li>
</ul>
';

		return $ret;
	}

	function _daily() {
		$this->theme->title='จำนวนการปักหมุดในแต่ละวัน';
		$ret.='<form method="GET"><label for="from">จากวันที่</label>
<input type="text" id="from" name="from" class="form-text" value="'.$_REQUEST['from'].'" />
<label for="to">ถึง </label><input type="text" id="to" name="to" class="form-text" value="'.$_REQUEST['to'].'" /> <button>ดูรายงาน</button></form>';

		$where=array();
		if ($_REQUEST['from']) $where=sg::add_condition($where,'`created`>=:from ','from',sg_date($_REQUEST['from'],'U'));
		if ($_REQUEST['to']) $where=sg::add_condition($where,'`created`<=:to ','to',sg_date($_REQUEST['to'],'U'));

		$stmt='SELECT FROM_UNIXTIME(`created`, "%Y-%m-%d") `date`, COUNT(*) `amt`
						FROM %map_networks%
						'.($where?'WHERE '.implode(' AND ',$where['cond']):'').'
						GROUP BY `date` ORDER BY `date` ASC';
		$dbs=mydb::select($stmt,$where['value']);

		$lastDate=get_first($_REQUEST['to'],end($dbs->items)->date);
		$date=$firstDate=get_first($_REQUEST['from'],reset($dbs->items)->date);

		$graph->title='จำนวนหมุด';
		$graph->items[]=array('วัน-เดือน-ปี','จำนวนหมุด');

		foreach ($dbs->items as $rs) $data[$rs->date]=$rs->amt;
		do {
			$graph->items[]=array(sg_date($date,'d-m'),get_first($data[$date],0));
			list($y,$m,$d)=explode('-', $date);
			$date=date('Y-m-d',mktime(0,0,0, intval($m), intval($d)+1, intval($y) ));
		} while ($date<=$lastDate);

		head('<script type="text/javascript" src="/library/js/jquery.jeditable.js"></script>');
		head('jspi','<script type="text/javascript" src="https://www.google.com/jsapi"></script>');
		$ret.='<div id="chart_div" style="width: 100%; height: 600px;"></div>';
		$ret.='<script type="text/javascript">
google.load("visualization", "1", {packages:["corechart"]});
google.setOnLoadCallback(drawChart);
function drawChart() {
	var data = google.visualization.arrayToDataTable('.json_encode($graph->items).');
	var options = {title: "'.$graph->title.'",};
	var chart = new google.visualization.LineChart(document.getElementById("chart_div"));
	chart.draw(data, options);
}
 $(function() {
$( "#from" ).datepicker({
defaultDate: "-1m",
changeMonth: true,
numberOfMonths: 3,
dateFormat: "yy-mm-dd",
onClose: function( selectedDate ) {
$( "#to" ).datepicker( "option", "minDate", selectedDate );
}
});
$( "#to" ).datepicker({
defaultDate: "-1m",
changeMonth: true,
numberOfMonths: 3,
dateFormat: "yy-mm-dd",
onClose: function( selectedDate ) {
$( "#from" ).datepicker( "option", "maxDate", selectedDate );
}
});
});
</script>';
		return $ret;
	}

	function _month() {
		$this->theme->title='จำนวนการปักหมุดในแต่ละเดือน';
		$ret.='<form method="GET"><label for="from">จากวันที่</label>
<input type="text" id="from" name="from" class="form-text" value="'.$_REQUEST['from'].'" />
<label for="to">ถึง </label><input type="text" id="to" name="to" class="form-text" value="'.$_REQUEST['to'].'" /> <button>ดูรายงาน</button></form>';

		$where=array();
		if ($_REQUEST['from']) $where=sg::add_condition($where,'`created`>=:from ','from',sg_date($_REQUEST['from'],'U'));
		if ($_REQUEST['to']) $where=sg::add_condition($where,'`created`<=:to ','to',sg_date($_REQUEST['to'],'U'));

		$stmt='SELECT FROM_UNIXTIME(`created`, "%Y-%m") `date`, COUNT(*) `amt`
						FROM %map_networks%
						'.($where?'WHERE '.implode(' AND ',$where['cond']):'').'
						GROUP BY `date` ORDER BY `date` ASC';
		$dbs=mydb::select($stmt,$where['value']);

		$lastDate=get_first($_REQUEST['to'],end($dbs->items)->date);
		$date=$firstDate=get_first($_REQUEST['from'],reset($dbs->items)->date);

		$tables->class='item';
		$graph->title='จำนวนหมุด';
		$tables->thead=$graph->items[]=array('เดือน-ปี','จำนวนหมุด');

		foreach ($dbs->items as $rs) {
			$data[$rs->date]=$rs->amt;
			$tables->rows[]=array(sg_date($rs->date.'-01','ดดด ปปปป'),$rs->amt);
			$total+=$rs->amt;
		}
		$tables->tfoot[]=array('รวม',$total);
		do {
			$graph->items[]=array(sg_date($date.'-01','m-Y'),get_first($data[$date],0));
			list($y,$m,$d)=explode('-', $date.'-01');
			$date=date('Y-m',mktime(0,0,0, intval($m)+1, intval($d), intval($y) ));
		} while ($date<=$lastDate);

		$ret.='<div id="chart_div" style="width: 100%; height: 600px;"></div>';
		$ret.=theme('table',$tables);

		head('<script type="text/javascript" src="/library/js/jquery.jeditable.js"></script>');
		head('jspi','<script type="text/javascript" src="https://www.google.com/jsapi"></script>');
		$ret.='<script type="text/javascript">
google.load("visualization", "1", {packages:["corechart"]});
google.setOnLoadCallback(drawChart);
function drawChart() {
	var data = google.visualization.arrayToDataTable('.json_encode($graph->items).');
	var options = {title: "'.$graph->title.'",};
	var chart = new google.visualization.ColumnChart(document.getElementById("chart_div"));
	chart.draw(data, options);
}
 $(function() {
$( "#from" ).datepicker({
defaultDate: "-1m",
changeMonth: true,
numberOfMonths: 3,
dateFormat: "yy-mm-dd",
onClose: function( selectedDate ) {
$( "#to" ).datepicker( "option", "minDate", selectedDate );
}
});
$( "#to" ).datepicker({
defaultDate: "-1m",
changeMonth: true,
numberOfMonths: 3,
dateFormat: "yy-mm-dd",
onClose: function( selectedDate ) {
$( "#from" ).datepicker( "option", "maxDate", selectedDate );
}
});
});
</script>';
		return $ret;
	}

	function _growth() {
		$this->theme->title='จำนวนการเพิ่มขึ้นของหมุดในแต่ละวัน';
	$ret.='<form method="GET"><label for="from">จากวันที่</label>
<input type="text" id="from" name="from" class="form-text" value="'.$_REQUEST['from'].'" />
<label for="to">ถึง </label><input type="text" id="to" name="to" class="form-text" value="'.$_REQUEST['to'].'" /> <button>ดูรายงาน</button></form>';

		$where=array();
		if ($_REQUEST['from']) $where=sg::add_condition($where,'`created`>=:from ','from',sg_date($_REQUEST['from'],'U'));
		if ($_REQUEST['to']) $where=sg::add_condition($where,'`created`<=:to ','to',sg_date($_REQUEST['to'],'U'));

		$stmt='SELECT FROM_UNIXTIME(`created`, "%Y-%m-%d") `date`, COUNT(*) `amt`
						FROM %map_networks%
						'.($where?'WHERE '.implode(' AND ',$where['cond']):'').'
						GROUP BY `date` ORDER BY `date` ASC';
		$dbs=mydb::select($stmt,$where['value']);

		$lastDate=get_first($_REQUEST['to'],end($dbs->items)->date);
		$date=$firstDate=get_first($_REQUEST['from'],reset($dbs->items)->date);

		$graph->title='จำนวนหมุด';
		$graph->items[]=array('วัน-เดือน-ปี','จำนวนหมุด');

		foreach ($dbs->items as $rs) $data[$rs->date]=$rs->amt;
		do {
			$growth+=$data[$date];
			$graph->items[]=array(sg_date($date,'d-m'),$growth);
			list($y,$m,$d)=explode('-', $date);
			$date=date('Y-m-d',mktime(0,0,0, intval($m), intval($d)+1, intval($y) ));
		} while ($date<=$lastDate);

		head('<script type="text/javascript" src="/library/js/jquery.jeditable.js"></script>');
		head('jspi','<script type="text/javascript" src="https://www.google.com/jsapi"></script>');
		$ret.='<div id="chart_div" style="width: 100%; height: 600px;"></div>';
		$ret.='<script type="text/javascript">
google.load("visualization", "1", {packages:["corechart"]});
google.setOnLoadCallback(drawChart);
function drawChart() {
	var data = google.visualization.arrayToDataTable('.json_encode($graph->items).');
	var options = {title: "'.$graph->title.'",};
	var chart = new google.visualization.LineChart(document.getElementById("chart_div"));
	chart.draw(data, options);
}
 $(function() {
$( "#from" ).datepicker({
defaultDate: "-1m",
changeMonth: true,
numberOfMonths: 3,
dateFormat: "yy-mm-dd",
onClose: function( selectedDate ) {
$( "#to" ).datepicker( "option", "minDate", selectedDate );
}
});
$( "#to" ).datepicker({
defaultDate: "-1m",
changeMonth: true,
numberOfMonths: 3,
dateFormat: "yy-mm-dd",
onClose: function( selectedDate ) {
$( "#from" ).datepicker( "option", "maxDate", selectedDate );
}
});
});
</script>';
		return $ret;
	}

} // end of class map_help
?>