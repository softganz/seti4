<?php
/**
 * calendar_room class for meeting room reservation management
 *
 * @package calendar
 * @version 0.10
 * @copyright Copyright (c) 2000-present , The SoftGanz Group By Panumas Nontapan
 * @author Panumas Nontapan <webmaster@softganz.com> , http://www.softganz.com
 * @created 2011-10-25
 * @modify 2012-10-01
 * ============================================
 * This program is free software. You can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License.
 * ============================================
 */

menu('meeting/list','Room Reservation Listing','meeting','listing',3,'access meetings','static');
menu('meeting/post','Room Reservation Post','meeting','post',3,'administer meetings,create meeting content','static');
menu('meeting/*/edit','Room Reservation Modify','meeting','edit',1,'method permission','dynamic');
menu('meeting/*/remove','Room Reservation Remove','meeting','remove',1,'method permission','dynamic');
menu('meeting/*','Room Reservation Detail','meeting','view',1,'access meetings','dynamic');
menu('meeting','Room Reservation main page','meeting','home',1,'access meetings','static');

//error_reporting(E_ALL ^ E_NOTICE ^E_WARNING);
class calendar_room extends calendar_base {
var $module='calendar';
var $date_format = '/^(0[1-9]|[12][[:digit:]]|3[01]|[1-9])[\/](0[1-9]|1[012]|[1-9])[\/]([123456789][[:digit:]]{3})$/';

	function __construct() {
	    parent::__construct(); //Call parents constructor
		$this->property=property('calendar.room');
		$this->theme->title=SG\getFirst($this->property['title'],'ระบบจองห้องประชุม');
		if (!cfg('calendar.secondary')) cfg('web.secondary',false);
	}










	function _edit($id) {
		$rs = R::Model('calendar.get.resv',$id);

		if (!user_access('administer calendar rooms','edit own calendar room content',$rs->uid)) return message('error','Access denied');

		if ($_POST['cancel']) location('calendar/room/info/'.$id);

		$this->theme->title=$rs->title;
		$this->theme->toolbar= $this->__toolbar($rs);

		if ($_POST) {
			$post=(object)post('room',_TRIM+_STRIPTAG);
			if (empty($post->checkin)) $field_missing[]='วันที่-เดือน-ปีที่จอง';
			if (empty($post->from_time) || empty($post->to_time)) $field_missing[]='ตั้งแต่เวลา-ถึงเวลา';
			if (empty($post->resv_by)) $field_missing[]='จองโดยใคร';
			if (empty($post->org_name) && empty($post->org_name_etc)) $field_missing[]='หน่วยงานอะไร';
			if (empty($post->title)) $field_missing[]='ทำอะไร';
			if ($field_missing) $error[]='กรุณาป้อนข้อมูลต่อไปนี้ให้ครบถ้วน : <ol><li>'.implode('</li><li>',$field_missing).'</li></ol>';

			if (!$error) {
				// start save new item
				$simulate=debug('simulate');

				$post->resvid=$id;
				preg_match($this->date_format,$post->checkin,$from_date);
				$post->checkin=sprintf('%04d',$from_date[3]).'-'.sprintf('%02d',$from_date[2]).'-'.sprintf('%02d',$from_date[1]);
				$post->org_name=SG\getFirst($post->org_name,$post->org_name_etc);
				$post->equipment=SG\getFirst(implode(',',$post->equipment),'func.NULL');
				$stmt='UPDATE %calendar_room% SET
									`roomid`=:roomid, `title`=:title, `body`=:body, `resv_by`=:resv_by, `org_name`=:org_name, `checkin`=:checkin,
									`from_time`=:from_time, `to_time`=:to_time, `peoples`=:peoples, `equipment`=:equipment, `phone`=:phone
								WHERE `resvid`=:resvid';
				mydb::query($stmt,$post);
				//				$ret.=print_o($post,'$post');
				//				$ret.=mydb()->_query;

				if ($simulate) {
					$ret.=implode('<br />',$query);
				} else {
					location('calendar/room/info/'.$id);
				}
			}
		} else {
			$post=$rs;
			$post->checkin=sg_date($rs->checkin,'d/m/Y');
			$post->equipment=explode(',',$post->equipment);
		}
		if ($error) $ret.=message('error',$error);
		$ret.=$this->_post_form($post);
		//		$ret.=print_o($post,'$post');
		return $ret;
	}





	/**
	 * Administrator main page
	 *
	 * @return String
	 */


} // end of class meeting
?>
