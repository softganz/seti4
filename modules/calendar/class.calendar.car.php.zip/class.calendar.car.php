<?php
/**
 * calendar_car class for car reservation management
 *
 * @package calendar
 * @version 0.00a
 * @copyright Copyright (c) 2000-present , The SoftGanz Group By Panumas Nontapan
 * @author Panumas Nontapan <webmaster@softganz.com> , http://www.softganz.com
 * @created 2012-11-16
 * @modify 2013-03-12
 * ============================================
 * This program is free software. You can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License.
 * ============================================
 */

class calendar_car extends calendar_base {
var $module='calendar';
var $date_format = '/^(0[1-9]|[12][[:digit:]]|3[01]|[1-9])[\/](0[1-9]|1[012]|[1-9])[\/]([123456789][[:digit:]]{3})$/';

	function __construct() {
		parent::__construct(); //Call parents constructor
		cfg('page_id','calendar-car');
		$this->property=property('calendar.car');
		if (empty($this->property['title'])) $this->property['title']='ระบบจองยานพาหนะ';
		$this->theme->title=$this->property['title'];
	}

	/**
	 * Module permission
	 *
	 * User permission to access menu
	 *
	 * @return String $permision Permission seperate by ,
	 */
	function permission() { return 'access calendar cars,administer calendar cars,create calendar car content,edit own calendar car content';}

	function install() {
		$stmt='CREATE TABLE %calendar_car% (
						`calid` int(10) unsigned NOT NULL,
						`carid` int(10) unsigned DEFAULT NULL,
						`dateresv` date DEFAULT NULL,
						`resvby` varchar(50) DEFAULT NULL,
						`depart` int(10) unsigned DEFAULT NULL,
						`objective` int(10) unsigned DEFAULT NULL,
						`phone` varchar(20) DEFAULT NULL,
						`driver` int(10) unsigned DEFAULT NULL,
						`kmfrom` int(10) unsigned NOT NULL DEFAULT 0,
						`kmto` int(10) unsigned NOT NULL DEFAULT 0,
						PRIMARY KEY (`calid`),
						KEY `carid` (`carid`),
						KEY `driver` (`driver`)
						)';
		mydb::query($stmt);
	}

	function __controller($method) {
		$args=func_get_args();

		$page.=call_user_func_array(array(parent,'__controller'),$args);
		if (_AJAX) {
			return $page;
		}

		$is_edit=user_access('administer calendar cars');
		$ui=new ui();
		$ui->add('<a href="'.url('calendar/car/list/'.$rs->calid).'" title="รายการจองใช้รถ" data-rel="#app-output" class="sg-action icon-list">รายการจองใช้รถ</a>');
		$ui->add('<a href="'.url('calendar/car/month').'" title="ปฏิทินการจองใช้รถ" data-rel="#app-output" class="sg-action icon-calendar">ปฏิทินการจองใช้รถ</a>');
		$ui->add('<a href="'.url('calendar/car/resv').'" class="sg-action icon-add" data-rel="#app-output" title="ลงบันทึกการจองใช้รถ">ลงบันทึกการจองใช้รถ</a>');
		$ret.='<div class="toolbar" id="toolbar-main">'.$ui->build('ul').'</div>'._NL;
		$ui->clear();
		if ($is_edit) {
			$ui->add('<a href="'.url('calendar/car/setting').'" title="Setting" class="icon-setting">Setting</a>');
			$ret.='<div class="toolbar" id="toolbar-setting">'.$ui->build('ul').'</div>'._NL;
		}

		// Start of app sidebar
		$ret.='<div class="app-sidebar">'._NL;

		$ret.='<div class="app-main">'._NL;
		$ret.='<div class="sg-load" data-url="'.url('calendar/tiny_month').'"></div>';
		$ui=new ui();
		$ui->add('<a href="'.url('calendar/car').'">หน้าหลัก</a>');
		$ui->add('<a class="sg-action" href="'.url('calendar/car/list'.($id?'/'.$id:'')).'" data-rel="#app-output">รายการจองใช้รถ</a>');
		$ui->add('<a class="sg-action" href="'.url('calendar/car/resv').'" data-rel="#app-output">ลงบันทึกการจองใช้รถ</a>');
		$ui->add('<strong>ประมวลผล - ประเด็นเที่ยววิ่ง</strong>');
		$ui->add('<a href="'.url('calendar/car/report_km').'">วิ่งกี่เที่ยว/ปี/เดือน</a>');
		$ui->add('<a href="'.url('calendar/car/report_driver').'">แยกพนง.ว่าแต่ละคนวิ่งได้กี่เที่ยว/เดือน/ปี</a>');
		$ui->add('<a href="'.url('calendar/car/report_car').'">รถแต่ละคันวิ่งได้กี่เที่ยว/เดือน/ปี</a>');
		$ui->add('<strong>ประมวลผล - ประเด็นระยะทาง</strong>');
		$ui->add('<a href="'.url('calendar/car/report_km').'">วิ่งทั้งหมด กี่ กม.</a>');
		$ui->add('<a href="'.url('calendar/car/report_driver').'">แยกพนง.ว่าแต่ละคนวิ่งได้กี่ กม./เดือน/ปี</a>');
		$ui->add('<a href="'.url('calendar/car/report_car').'">รถแต่ละคันวิ่งได้กี่ กม./เดือน/ปี</a>');
		$ret.=$ui->build('ul');

		$ret.='</div><!--app-main-->'._NL;

		$ret.='<div class="app-sub">'._NL;
		$ret.='</div><!--app-sub-->'._NL;

		$ret.='</div><!-- sidebar -->'._NL;
		// End of app sidebar

		// Start of app output
		$ret.='<div class="app-output" id="app-output">';
		$ret.=$page;
		$ret.='</div>'._NL;
		$ret.='<div class="app-footer"></div>';

		head('<script type="text/javascript" src="https://www.google.com/jsapi" charset="utf-8"></script>');

		head('<script type="text/javascript"><!--
		var debug='.(isset($_REQUEST['debug'])?'true':'false').';

		$(document).ready(function() {
			$(window).resize(function() {
				resize();
			});
			resize();
			function resize() {
				if (debug) notify($(window).width());
				$(".app-sidebar").css("width","200px");
				var outputWidth=$("#primary").width()-$(".app-sidebar").width()-40;
				$(".app-output").css({width:outputWidth+"px", "margin-left":"20px"});
		//		notify("output width="+outputWidth+" sidebar width="+$(".app-sidebar").width()+" left="+$(".app-output").css("margin-left"));

		//			var contentHeight=($(window).height()-$("#header-wrapper").height()-$("h2.title").height()-$(".app-sidebar").height()-$(".app-footer").height())+"px";
		//			$("#content-wrapper").height(contentHeight);
		//			notify(contentHeight);

		//			var listHeight=($(".app-sidebar").height()-$(".app-main").height())+"px";
		//			$(".app-sub").height(listHeight);

			}
		});
		--></script>');
		return $ret;
	}

	function _home() {
		$para=para(func_get_args());


		// Start of app output
		//		$ret.='<div class="sg-load app-output" id="app-output" data-url="calendar/car/list">';
		//		$ret.='</div>'._NL;
		if ($this->property['detail']) {
			$ret.=sg_text2html($this->property['detail']);
		} else {
			$ret.=$this->_list();
		}
		return $ret;
	}

	function __submenu($rs) {
		$is_edit=user_access('administer calendar cars','edit own calendar car content',$rs->owner);
		$ui=new ui();
		$ui->add('<a href="'.url('calendar/car/view/'.$rs->calid).'" title="ดูรายละเอียด" data-rel="#app-output" class="sg-action icon-view">รายละเอียด</a>');
		if ($is_edit) {
			$ui->add('<a href="'.url('calendar/car/resv/'.$rs->calid).'" title="แก้ไขรายการ" data-rel="#app-output" class="sg-action icon-edit">แก้ไข</a>');
			if (user_access('administer calendar cars')) {
				$ui->add('<a href="'.url('calendar/car/driver/'.$rs->calid).'" title="บันทึกชื่อ พนง.ขับรถ" data-rel="#app-output" class="sg-action icon-driver">บันทึกชื่อ พนง.ขับรถ</a>');
				$ui->add('<a href="'.url('calendar/car/km/'.$rs->calid).'" title="บันทึกเลข กม." data-rel="#app-output" class="sg-action icon-km">บันทึกเลข กม.</a>');
			}
			$ui->add('&nbsp;');
			$ui->add('<a href="'.url('calendar/car/delete/'.$rs->calid).'" title="ลบรายการ" data-rel="#app-output" class="sg-action icon-delete" confirm="ต้องการลบรายการนี้จริงหรือไม่?">ลบ</a>');
		}
		$ret.='<div class="toolbar">'.$ui->build('ul').'</div>';
		return $ret;
	}

	function _resv($id) {
		if (!user_access('administer calendar cars,create calendar car content')) return message('error','access denied');
		$this->theme->title='ลงบันทึกการขอจองใช้รถ';
		$post=(object)post('car');

		if ($_POST['save']) {
			$post->calid=SG\getFirst($post->calid,NULL);
			$post->privacy="public";
			$post->title='จองรถ - '.mydb::select('SELECT name FROM %tag% where `tid`=:tid LIMIT 1',':tid',$post->carid)->name;

			// Convert date from dd/mm/yyyy to yyyy-mm-dd
			list($dd,$mm,$yy)=explode('/',$post->from_date);
			if ($yy>2400) $yy=$yy-543;
			$post->from_date=sprintf('%04d',$yy).'-'.sprintf('%02d',$mm).'-'.sprintf('%02d',$dd);

			list($dd,$mm,$yy)=explode('/',$post->dateresv);
			if ($yy>2400) $yy=$yy-543;
			$post->dateresv=sprintf('%04d',$yy).'-'.sprintf('%02d',$mm).'-'.sprintf('%02d',$dd);

			//			$post->from_date=sg_date($post->from_date,'Y-m-d');
			//			$post->dateresv=sg_date($post->dateresv,'Y-m-d');
			$post->owner=SG\getFirst(i()->uid,'func.NULL');
			$post->created_date=date('Y-m-d H:i:s');

			// Add item into calendar
			$stmt='INSERT INTO %calendar%
								(`id`, `owner`, `privacy`, `title`, `from_date`, `from_time`, `to_time`,`created_date`)
							VALUES
								(:calid, :owner, :privacy, :title, :from_date, :from_time, :to_time, :created_date)
							ON DUPLICATE KEY UPDATE `title`=:title, `from_date`=:from_date, `from_time`=:from_time, `to_time`=:to_time;';
			mydb::query($stmt,$post);
			//			$ret.=mydb()->_query;

			// Add information into calendar_car
			if (empty($post->calid)) $post->calid=mydb()->insert_id;
			$stmt='INSERT INTO %calendar_car%
								(`calid`, `carid`, `dateresv`, `place`, `people`, `resvby`, `depart`, `objective`, `issues`, `phone`)
							VALUES
								(:calid, :carid, :dateresv, :place, :people, :resvby, :depart, :objective, :issues, :phone)
							ON DUPLICATE KEY UPDATE `dateresv`=:dateresv, `place`=:place, `people`=:people, `resvby`=:resvby, `depart`=:depart, `objective`=:objective, `issues`=:issues, `phone`=:phone;';
			mydb::query($stmt,$post);
			//			$ret.=mydb()->_query;

			$ret.=$this->_list();
			return $ret;
		} else {
			$post=$this->__get_by_id($id);
		}

		if ($post->calid) $ret.=$this->__submenu($post);

		$form->config->variable='car';
		$form->config->method='post';
		$form->config->action=url(q());
		$form->config->title=$this->theme->title;

		if ($post->calid) $form->calid=array('type'=>'hidden','value'=>$post->calid);

		$form->carid=array('type'=>'select', 'label'=>'รถที่ขอจอง', 'require'=>true, 'options'=>array('===เลือก===')+$this->__category('car.carname'), 'value'=>$post->carid);
		$form->dateresv=array('type'=>'text', 'label'=>'วันที่จอง', 'size'=>10, 'require'=>true,'value'=>SG\getFirst($post->dateresv?sg_date($post->dateresv,'d/m/Y'):NULL,date('d/m/Y')));
		$form->from_date=array('type'=>'text', 'label'=>'วันที่ใช้รถ', 'size'=>10, 'require'=>true,'value'=>SG\getFirst($post->from_date?sg_date($post->from_date,'d/m/Y'):NULL),'placeholder'=>'วว/ดด/ค.ศ.');
		$form->from_time=array('type'=>'text', 'label'=>'เวลาไป', 'size'=>10, 'require'=>true, 'value'=>htmlspecialchars(substr($post->from_time,0,5)),'placeholder'=>'00:00');
		$form->to_time=array('type'=>'text', 'label'=>'เวลากลับ', 'size'=>10, 'require'=>true, 'value'=>htmlspecialchars(substr($post->to_time,0,5)),'placeholder'=>'00:00');
		$form->place=array('type'=>'text', 'label'=>'สถานที่ไป', 'size'=>30, 'value'=>htmlspecialchars($post->place));
		$form->people=array('type'=>'text', 'label'=>'จำนวนผู้ร่วมเดินทาง(คน)', 'size'=>3, 'value'=>htmlspecialchars($post->people));

		$form->resvby=array('type'=>'text', 'label'=>'ชื่อผู้ขอใช้', 'size'=>30, 'require'=>true, 'value'=>htmlspecialchars($post->resvby));
		$form->depart=array('type'=>'select', 'label'=>'หน่วยงานที่ใช้', 'require'=>true, 'options'=>array('===เลือก===')+$this->__category('car.depart'), 'value'=>$post->depart);
		$form->objective=array('type'=>'select', 'label'=>'วัตถุประสงค์การใช้', 'require'=>true, 'options'=>array('===เลือก===')+$this->__category('car.objective'), 'value'=>$post->objective);
		$form->issues=array('type'=>'text', 'label'=>'ประเด็น', 'size'=>30, 'value'=>htmlspecialchars($post->issues));
		$form->phone=array('type'=>'text', 'label'=>'โทรศัพท์ติดต่อ', 'size'=>30, 'require'=>true, 'value'=>htmlspecialchars($post->phone));

		//		$form->driver=array('type'=>'select', 'label'=>'ชื่อ พนง.ขับรถ', 'require'=>true, 'options'=>array('===เลือก===')+$this->__category('car.driver'), 'value'=>$post->driver);
		//		$form->kmfrom=array('type'=>'text', 'label'=>'เลข กม.เริ่มใช้', 'size'=>10, 'value'=>htmlspecialchars($post->kmfrom), 'placeholder'=>'0');
		//		$form->kmto=array('type'=>'text', 'label'=>'เลข กม.ภายหลังใช้', 'size'=>10, 'value'=>htmlspecialchars($post->kmto), 'placeholder'=>'0');

		$form->submit->type='submit';
		$form->submit->items->save=tr('Save');

		$ret.=theme('form','car-resv',$form);

		$ret.='<script>
		$(document).ready(function() {
			$("#car-resv").submit(function() {
				var $this=$(this);
				var error;
				$this.find(".require").each(function(i) {
					var $require=$(this);
					if ($require.val().empty()) {
						error="กรุณาป้อน "+$require.prevAll("label").text();
						$require.focus();
						return false;
					}
				});
				if (error) {
					notify(error);
					return false;
				}

				notify("กำลังบันทึก");
				$.post($this.attr("action"),"save=บันทึก"+"&"+$this.serialize(), function(data) {
					$("#app-output").html(data);
					notify();
				});
				return false;
			});

			$("#edit-car-dateresv, #edit-car-from_date").datepicker({
				dateFormat: "dd/mm/yy",
				disabled: false,
				monthNames: thaiMonthName
			});

		});
		</script>
		 ';
		//		$ret.=print_o($post,'$post');
		//		$ret.=print_o($_POST,'$_POST');
		return $ret;
	}

	function _driver($id) {
		$this->theme->title='ลงบันทึก พนง.ขับรถ';
		$rs=$this->__get_by_id($id);
		$ret.=$this->__submenu($rs);
		if (!user_access('administer calendar cars')) return $ret.message('error','access denied');

		if ($rs->calid && $_REQUEST['d']) {
			// Add item into calendar
			$stmt='UPDATE %calendar_car% SET `driver`=:driver WHERE `calid`=:calid LIMIT 1';
			mydb::query($stmt,':calid',$id,':driver',$_REQUEST['d']);
			$ret.=$this->_view($rs->calid);
			return $ret;
		} else if ($rs->calid) {
			$is_edit=user_access('administer calendar cars','edit own calendar car',$post->owner);

			$ret.='<h3>เลือกชื่อ พนง.ขับรถ?</h3>';
			$ret.='<ul class="calendar-car-driver">';
			foreach ($this->__category('car.driver') as $k=>$v) {
				$ret.='<li><a class="sg-action" href="'.url('calendar/car/driver/'.$id,'d='.$k).'" data-rel="#app-output">'.$v.'</a></li>';
			}
			$ret.='</ul>';
		}
		return $ret;
	}

	function _km($id) {
		$this->theme->title='ลงบันทึกเลข กม.';
		$rs=$this->__get_by_id($id);
		$ret.=$this->__submenu($rs);
		if (!user_access('administer calendar cars')) return $ret.message('error','access denied');

		if ($rs->calid && $_REQUEST['car']) {
			// Add item into calendar
			$stmt='UPDATE %calendar_car% SET `kmfrom`=:kmfrom, `kmto`=:kmto WHERE `calid`=:calid LIMIT 1';
			mydb::query($stmt,':calid',$rs->calid, $_REQUEST['car']);
			//			$ret.=mydb()->_query;
			$ret.=$this->_view($rs->calid);
			return $ret;
		} else if ($rs->calid) {
			$is_edit=user_access('administer calendar cars','edit own calendar car',$post->owner);
		}
		$form->config->variable='car';
		$form->config->method='post';
		$form->config->action=url(q());
		$form->config->title=$this->theme->title;

		$form->kmfrom=array('type'=>'text', 'label'=>'เลข กม.เริ่มใช้', 'size'=>10, 'value'=>htmlspecialchars($rs->kmfrom), 'placeholder'=>'0');
		$form->kmto=array('type'=>'text', 'label'=>'เลข กม.ภายหลังใช้', 'size'=>10, 'value'=>htmlspecialchars($rs->kmto), 'placeholder'=>'0');

		$form->submit->type='submit';
		$form->submit->items->save=tr('Save');

		$ret.=theme('form','car-resv',$form);

		$ret.='<script>
		$(document).ready(function() {
			$("#car-resv").submit(function() {
				var $this=$(this);
				var error;
				$this.find(".require").each(function(i) {
					var $require=$(this);
					if ($require.val().empty()) {
						error="กรุณาป้อน "+$require.prevAll("label").text();
						$require.focus();
						return false;
					}
				});
				if (error) {
					notify(error);
					return false;
				}

				notify("กำลังบันทึก");
				$.post($this.attr("action"),"save=บันทึก"+"&"+$this.serialize(), function(data) {
					$("#app-output").html(data);
					notify();
				});
				return false;
			});
		});
		</script>
		 ';
		//		$ret.=print_o($post,'$post');
		//		$ret.=print_o($_POST,'$_POST');
		return $ret;
	}

	/**
	 * View information
	 *
	 * @param Integer $id
	 * @return String
	 */
	function _view($id) {
		$rs=$this->__get_by_id($id);
		$this->theme->title=$rs->carname;

		if ($_POST && user_access('administer calendar cars','edit own calendar car content',$rs->uid)) {
			if ($_POST['ยกเลิก']) $approve='ยกเลิก';
			else if ($_POST['ไม่อนุมัติ'] && user_access('administer calendar cars')) $approve='ไม่อนุมัติ';
			else if ($_POST['อนุมัติ'] && user_access('administer calendar cars')) $approve='อนุมัติ';
			else if ($_POST['delete']) {
				mydb::query('DELETE FROM %calendar_car% WHERE `calid`=:calid LIMIT 1',':calid',$rs->calid);
				mydb::query('DELETE FROM %calendar% WHERE `id`=:calid LIMIT 1',':calid',$rs->calid);
			}
			if ($approve) {
				mydb::query('UPDATE %calendar_car% SET `approve`=:approve WHERE `calid`=:calid LIMIT 1',':calid',$rs->calid,':approve',$approve);
			}
			location('calendar/car');
		}

		$ret.=$this->__submenu($rs);

		$tables = new Table();
		$tables->id='calendar-car-info';
		$tables->caption='รายละเอียดการจองยานพาหนะ - '.$rs->carname;
		$tables->rows[]=array('รถที่ขอจอง', $rs->carname);
		$tables->rows[]=array('วันที่จอง', sg_date($rs->dateresv,'ว ดดด ปปปป'));
		$tables->rows[]=array('วันที่ใช้รถ', sg_date($rs->from_date,'ว ดดด ปปปป'));
		$tables->rows[]=array('เวลาไป', substr($rs->from_time,0,5).' น.');
		$tables->rows[]=array('เวลากลับ', substr($rs->to_time,0,5).' น.');
		$tables->rows[]=array('ชื่อผู้ขอใช้', $rs->resvby);
		$tables->rows[]=array('สถานที่ไป', $rs->place);
		$tables->rows[]=array('จำนวนผู้ร่วมเดินทาง(คน)', $rs->people);
		$tables->rows[]=array('หน่วยงานที่ใช้', $rs->departname);
		$tables->rows[]=array('วัตถุประสงค์การใช้', $rs->objectivename);
		$tables->rows[]=array('ประเด็น', $rs->issues);
		$tables->rows[]=array('โทรศัพท์ติดต่อ', $rs->phone);
		$tables->rows[]=array('ชื่อ พนง.ขับรถ', $rs->drivername);
		$tables->rows[]=array('เลข ก.ม. เริ่มใช้', number_format($rs->kmfrom));
		$tables->rows[]=array('เลข ก.ม. ภายหลังใช้', number_format($rs->kmto));

		$ret .= $tables->build();

		$ret.='<div id="calendar-car-status"><span class="button">'.$rs->approve.'</span>';
		if (user_access('administer calendar cars','edit own calendar car content',$rs->uid)) {
			$form->config->method='post';
			$form->config->action=url(q());

			$form->submit->label=$approve?'ดำเนินการเปลี่ยนสถานะเป็น '.$approve.' เรียบร้อยแล้ว':'คุณต้องการดำเนินการเปลี่ยนสถานะการจองยานพาหนะรายการนี้  ใช่หรือไม่?';

			$form->submit->type='submit';
			$form->submit->items->{"ยกเลิก"}='ยกเลิกการจอง';
			if (user_access('administer calendar cars')) {
				$form->submit->items->{"ไม่อนุมัติ"}='ไม่ผ่านอนุมัติ';
				$form->submit->items->{"อนุมัติ"}='ผ่านอนุมัติ';
			}
			$form->submit->items->delete='ลบรายการทิ้ง';
			$form->description='หมายเหตุ : หากเลือกจะทำการลบรายการทิ้ง ข้อมูลการจองรายการนี้ถูกลบทิ้งและจะไม่สามารถเรียกคืนได้อีกแล้ว';

			$ret .= theme('form','calendar-car-approve',$form);
			$ret.='<script type="text/javascript">
		$(document).ready(function() {
			$("form#calendar-car-approve").submit(function() {
		//		return false;
			});
			$("input[name=delete]").click(function() {
				return confirm("คุณกำลังจะลบการจองยานพาหนะรายการนี้ คุณแน่ใจหรือไม่ว่าต้องการจะลบ?");
			});
		});
		</script>';
		}
		$ret.='</div>';
		$ret.='<div class="calendar-car-distance">ระยะทางวิ่งได้ <span>'.number_format($rs->kmto-$rs->kmfrom).'</span> ก.ม.</div>';
		return $ret;
	}

	function _list($style=NULL) {
		$this->theme->title='รายการจองใช้รถ';
		$stmt='SELECT cr.calid, cr.approve, cr.dateresv, c.from_date, c.from_time, c.to_time, tcar.name carname, cr.resvby, tdepart.name departname, tobjectice.name objectivename, tdriver.name drivername
						FROM %calendar_car% cr
							LEFT JOIN %calendar% c ON c.id=cr.calid
							LEFT JOIN %tag% tcar ON tcar.tid=cr.carid
							LEFT JOIN %tag% tdepart ON tdepart.tid=cr.depart
							LEFT JOIN %tag% tobjectice ON tobjectice.tid=cr.objective
							LEFT JOIN %tag% tdriver ON tdriver.tid=cr.driver
						ORDER BY `from_date` DESC';
		$dbs=mydb::select($stmt);
		//		$ret.=print_o($dbs,'$dbs');

		$is_edit=user_access('administer calendar cars');
		$ui=new ui();
		$ui->add('<a href="'.url('calendar/car/list/table').'" title="รายการจองใช้รถ" data-rel="#app-output" class="sg-action icon-table">Table</a>');
		$ui->add('<a href="'.url('calendar/car/list/thumbnail').'" title="รายการจองใช้รถ" data-rel="#app-output" class="sg-action icon-thumbnail">Thumbnail</a>');
		$ui->add('<a href="'.url('calendar/car/list/icons').'" title="รายการจองใช้รถ" data-rel="#app-output" class="sg-action icon-icons">Icons</a>');
		$ret.='<div class="toolbar">'.$ui->build('ul').'</div>';

		$ui=new ui();
		$is_edit=user_access('administer calendar cars,create carlendar car');
		foreach ($dbs->items as $rs) {
			$ui->clear();
			$ui->add('<a href="'.url('calendar/car/view/'.$rs->calid).'" title="ดูรายละเอียด" data-rel="#app-output" class="sg-action icon-view">รายละเอียด</a>');
			$days=floor((strtotime($rs->from_date) - strtotime(date('Y-m-d'))) /  ( 60 * 60 * 24 ));
			if ($days>30) $class='more-month';
			else if ($days>15) $class='more-halfmonth';
			else if ($days>7) $class='more-week';
			else if ($days>1) $class='more-day';
			else if ($days==1) $class='more-tomorrow';
			else if ($days==0) $class='more-today';
			else if ($days<0) $class='more-pass';
			switch ($style) {
				case 'thumbnail' :
					$rows[]='<div class="date"><span class="day">'.sg_date($rs->from_date,'ว').'</span> <span class="month">'.sg_date($rs->from_date,'ดดด').'</span> <span class="year">'.sg_date($rs->from_date,'ปปปป').'</span><span class="time">เวลา '.substr($rs->from_time,0,5).' - '.substr($rs->to_time,0,5).' น.</span></div><!--date-->'._NL.'<h3><a class="sg-action" href="'.url('calendar/car/view/'.$rs->calid).'" title="ดูรายละเอียด" data-rel="#app-output">'.$rs->carname.'</a></h3><p>'.$rs->objectivename.'</p>';
					break;

				case 'icons' :
					$rows[]='<div class="date"><span class="day">'.sg_date($rs->from_date,'ว').'</span> <span class="month">'.sg_date($rs->from_date,'ดดด').'</span> <span class="year">'.sg_date($rs->from_date,'ปปปป').'</span><span class="time">เวลา '.substr($rs->from_time,0,5).' - '.substr($rs->to_time,0,5).' น.</span></div><!--date-->'._NL.'<h3><a class="sg-action" href="'.url('calendar/car/view/'.$rs->calid).'" title="ดูรายละเอียด" data-rel="#app-output">'.$rs->carname.'</a></h3><p>'.sg_date($rs->from_date,'ว ดด ปป').' เวลา '.substr($rs->from_time,0,5).'-'.substr($rs->to_time,0,5).'<br />เพื่อ'.$rs->objectivename.'</p>';
					break;

				default :
					$rows[]=array(sg_date($rs->from_date,'ววว ว ดด ปป'),
															substr($rs->from_time,0,5).'-'.substr($rs->to_time,0,5),
															'<td colspan="6"><a class="sg-action" href="'.url('calendar/car/view/'.$rs->calid).'" title="ดูรายละเอียด" data-rel="#app-output">'.$rs->carname.'</a></td>',
															'<span class="nowrap">'.$rs->approve.'</span>',
															'<td rowspan="2">'.$ui->build().'</td>',
															'config'=>array('class'=>$class),
															);
					$rows[]=array($days==0?'วันนี้':(($days>0?'อีก ':'ผ่านไป ').abs($days).' วัน'),'','',$rs->resvby,
															$rs->departname,
															$rs->objectivename,
															$rs->drivername,
															sg_date($rs->dateresv,'ว ดด ปป'),
															'',
															'config'=>array('class'=>$class),
															);
					break;
			}
			//			if ($is_edit && $rs->partientname) $tables->rows[]=array('<td colspan="2">&nbsp;</td>','<td colspan="8"><span>ชื่อคนไข้ : '.$rs->partientname.' </span><span>ที่อยู่ : '.$rs->partientaddr.'</span></td>','config'=>array('class'=>'drugcontrol-partient'));
		}
		if ($style=='thumbnail' || $style=='icons') {
			$ret.='<ul class="calendar-car-list-'.$style.'"><li>'.implode('</li><li>',$rows).'</li></ul>';
		} else {
			$tables = new Table();
			$tables->addClass('calendar-car-list-table');
			$tables->caption=$this->theme->title;
			$tables->thead=array('วันที่ใช้รถ','เวลา','ยานพาหนะ','ผู้ขอใช้','หน่วยงานที่ใช้','วัตถุประสงค์','พนง.ขับ','วันที่จอง','สถานะ','');
			$tables->rows=$rows;

			$ret .= $tables->build();
		}
		$ret.='<script type="text/javascript">
		$(document).ready(function() {
			$("[action=\'delete\']").
			click(function() {
				var $this=$(this);
				if (confirm("ยืนยันว่าจะลบรายการนี้จริง?")) {
					notify("กำลังลบ กรุณารอสักครู่...");
					$.get($this.attr("href"),function(data) {
						$this.closest("tr").remove();
						notify(data,5000);
					});
				}
				return false;
			});
		});
		</script>';
		//		$ret.=print_o($dbs,'$dbs');
		return $ret;
	}

	/**
	 * Project calendar
	 *
	 * @param Object $self
	 * @param Object $topic
	 * @param Object $para
	 * @param Object $body
	 * @return String
	 */
	function _month() {
		unset($body->comment,$body->comment_form,$body->docs);
		list($year,$month)=explode('-',date('Y-m'));
		$ui=new ui();
		$ui->add('<a href="'.url('calendar').'" title="Previous" class="icon-prev"> &lt </a>');
		$ui->add('<a href="'.url('calendar').'" title="Next" class="icon-next"> &gt; </a>');
		$ui->add('<a href="'.url('calendar').'" title="Today" class="icon-today">'.tr('Today').'</a>');
		$ui->add('<strong id="calendar-current-month">'.sg_date('ดดด ปปปป').'</strong>');
		$ret.='<div class="toolbar" id="calendar-nav">'.$ui->build('ul').'</div>'._NL;

		$ret.='<div id="calendar"></div>';
		$ret.='<script type="text/javascript">
		var cyear=year='.date('Y').';
		var cmonth=month='.date('m').';
		var loc="'.url('calendar').'";
		$(document).ready(function() {
			loadMonth(year,month);
			$("#calendar-nav a").click(function() {
				var title=$(this).attr("title");
		//		var hash = this.href.split("#")[1];
				if (title=="Previous") {month--;if (month<=0) {month=12;year--}}
				else if (title=="Next") {month++;if (month>12) {month=1;year++}}
				else if (title=="Today") {year=cyear;month=cmonth;}
				notify("Loading");
				loadMonth(year,month);
				return false;
			});

			function loadMonth(year,month) {
			//	var withoutHash = href.indexOf("#")>0?href.substr(0,href.indexOf("#")):href;
				para={year:year, month:month};
				if (typeof tpid != "undefined") para.tpid=tpid;
				notify("กำลังโหลดปฏิทินของเดือน "+thaiMonthName[parseInt(month-1)]+" "+(year+543));
				$.get(loc,para,function(data) {
					notify();
					$("#calendar").html(data);
					initCalendar();
				});
				return false;
			}
		});
		</script>';
		return $ret;
	}

	function _delete($id) {
		$rs=$this->__get_by_id($id);
		if (!user_access('administer calendar cars','edit own calendar car',$rs->owner)) return;

		$confirm=SG\getFirst($para->confirm,$_REQUEST['confirm']);
		if ($confirm=='no') {
			location('calendar/car/view/'.$id);
		} if ($confirm!='yes') {
			$form->config->method='post';
			$form->config->action=url(q());

			$form->confirm->type='radio';
			$form->confirm->name='confirm';
			$form->confirm->label='คุณต้องการลบรายการนี้ ใช่หรือไม่?';
			$form->confirm->options['no']='ไม่ ฉันไม่ต้องการลบ';
			$form->confirm->options['yes']='ใช่ ฉันต้องการลบทิ้ง';

			$form->submit->type='submit';
			$form->submit->items->proceed='ดำเนินการ';
			$form->description='คำเตือน : จะทำการลบข้อมูลรายการนี้และจะไม่สามารถเรียกคืนได้อีกแล้ว';

			$ret .= theme('form','delete',$form);
			return $ret;
		} else if ($confirm=='yes') {
		mydb::query('DELETE FROM %calendar_car% WHERE `calid`=:calid LIMIT 1',':calid',$id);
		mydb::query('DELETE FROM %calendar% WHERE `id`=:calid LIMIT 1',':calid',$id);
			$ret='ลบรายการเรียบร้อย';
			$ret=$this->_list();
		}
		return location('calendar/car');
	}

	function _report() {
		$this->theme->title='Report';
		return $ret;
	}

	function _report_km() {
		$this->theme->title='รายงานจำนวนเที่ยว';
		$stmt='SELECT YEAR(`from_date`) `years`, DATE_FORMAT(`from_date`,"%Y-%m") `month`, COUNT(*) `times`, SUM(`kmto`-`kmfrom`) `kmtotal`
						FROM %calendar_car% car
							LEFT JOIN %calendar% c ON car.calid=c.id
						WHERE `kmfrom`>0 AND `kmto`>0
						GROUP BY `month`
						ORDER BY `month` ASC';
		$dbs=mydb::select($stmt);
		$ret.='<div id="chart_div" style="height:400px;"></div>';
		$data->title='รายงานจำนวนเที่ยว';
		$ghead[]='เดือน-ปี';
		$ghead[]='จำนวนเที่ยว';
		$ghead[]='ระยะทาง';
		$data->items[]=$ghead;

		$tables = new Table();
		$tables->caption='รายงานจำนวนเที่ยว';
		$tables->thead=array('เดือน-ปี','amt times'=>'จำนวนเที่ยว (เที่ยว)','amt kmtotal'=>'ระยะทาง (ก.ม.)');
		foreach ($dbs->items as $rs) {
			$tables->rows[]=array(sg_date($rs->month.'-01','ดดด ปปปป'),number_format($rs->times),number_format($rs->kmtotal));
			$timetotals+=$rs->times;
			$kmtotals+=$rs->kmtotal;
			unset($gdata);
			$gdata[]=sg_date($rs->month.'-01','ดด ปป');
			$gdata[]=intval($rs->times);
			$gdata[]=intval($rs->kmtotal);
			$data->items[]=$gdata;
		}
		$tables->tfoot[]=array('รวมทั้งสิ้น',number_format($timetotals),number_format($kmtotals));

		$ret .= $tables->build();

		//		$ret.=print_o($data,'$data');
		//		$ret.=print_o($dbs,'$dbs');

		$ret.='
		<style type="text/css">
		table.item td {text-align:center;}
		table.item>tfoot>tr>td {font-weight:bold;background:#DDDDDD;}
		</style>
		<script type="text/javascript">
		google.load("visualization", "1", {packages:["corechart"]});
		google.setOnLoadCallback(drawChart);
		function drawChart() {
			var data = google.visualization.arrayToDataTable('.json_encode($data->items).');
			var options = {title: "'.$data->title.'",
									hAxis: {title: "เดือน-ปี", titleTextStyle: {color: "black"}},
									series:[
										{targetAxisIndex:0},
										{targetAxisIndex:1},
									],
									vAxes:[
										{title: "จำนวนเที่ยว (เที่ยว)"}, // Left axis
										{title: "ระยะทาง (ก.ม.)"} // Right axis
									]
					};
			var chart = new google.visualization.ColumnChart(document.getElementById("chart_div"));
			chart.draw(data, options);
		}
		</script>';

		return $ret;
	}

	function _report_driver() {
		$this->theme->title='รายงานแยกตามพนักงาน';
		$driver=$_REQUEST['driver'];
		$ret.='<form class="report-form" id="report-disease">';
		$ret.='<div class="form-item" style="width:80%;float:left;">';
		$ret.='<label>พนักงานขับ : </label><select name="driver" id="driver" class="form-select"><option value="">---เลือก---</option>';
		foreach ($this->__category('car.driver') as $k=>$driver_name) $ret.='<option value="'.$k.'"'.($k==$driver?' selected="selected"':'').'>'.$driver_name.'</option>';
		$ret.='</select>';
		$ret.='</div><div class="form-item" style="width:20%;float:right;"><input type="submit" class="button" value="ดูรายงาน" style="display:block;width:100%;font-size:1.3em;" /></div><br clear="all" />';
		$ret.='</form>';
		if (empty($driver)) return $ret.'กรุณาเลือกพนักงานขับ';

		$stmt='SELECT driver, YEAR(`from_date`) `years`, DATE_FORMAT(`from_date`,"%Y-%m") `month`, COUNT(*) `times`, SUM(`kmto`-`kmfrom`) `kmtotal`
						FROM %calendar_car% car
							LEFT JOIN %calendar% c ON car.calid=c.id
						WHERE `driver`=:driver AND `kmfrom`>0 AND `kmto`>0
						GROUP BY `month`
						ORDER BY `month` ASC';
		$dbs=mydb::select($stmt,':driver',$driver);
		$ret.='<div id="chart_div" style="height:400px;"></div>';
		$data->title='รายงานจำนวนเที่ยว';
		$ghead[]='เดือน-ปี';
		$ghead[]='จำนวนเที่ยว';
		$ghead[]='ระยะทาง';
		$data->items[]=$ghead;

		$tables = new Table();
		$tables->caption='รายงานแยกตามพนักงาน';
		$tables->thead=array('เดือน-ปี','amt times'=>'จำนวนเที่ยว (เที่ยว)','amt kmtotal'=>'ระยะทาง (ก.ม.)');
		foreach ($dbs->items as $rs) {
			$tables->rows[]=array(sg_date($rs->month.'-01','ดดด ปปปป'),number_format($rs->times),number_format($rs->kmtotal));
			$timetotals+=$rs->times;
			$kmtotals+=$rs->kmtotal;
			unset($gdata);
			$gdata[]=sg_date($rs->month.'-01','ดด ปป');
			$gdata[]=intval($rs->times);
			$gdata[]=intval($rs->kmtotal);
			$data->items[]=$gdata;
		}
		$tables->tfoot[]=array('รวมทั้งสิ้น',number_format($timetotals),number_format($kmtotals));

		$ret .= $tables->build();

		//		$ret.=print_o($data,'$data');
		//		$ret.=print_o($dbs,'$dbs');

		$ret.='
		<style type="text/css">
		table.item td {text-align:center;}
		table.item>tfoot>tr>td {font-weight:bold;background:#DDDDDD;}
		</style>
		<script type="text/javascript">
		google.load("visualization", "1", {packages:["corechart"]});
		google.setOnLoadCallback(drawChart);
		function drawChart() {
			var data = google.visualization.arrayToDataTable('.json_encode($data->items).');
			var options = {title: "'.$data->title.'",
									hAxis: {title: "เดือน-ปี", titleTextStyle: {color: "black"}},
									series:[
										{targetAxisIndex:0},
										{targetAxisIndex:1},
									],
									vAxes:[
										{title: "จำนวนเที่ยว (เที่ยว)"}, // Left axis
										{title: "ระยะทาง (ก.ม.)"} // Right axis
									]
					};
			var chart = new google.visualization.ColumnChart(document.getElementById("chart_div"));
			chart.draw(data, options);
		}
		</script>';

		return $ret;
	}

	function _report_car() {
		$this->theme->title='รายงานแยกตามรถ';
		$carid=$_REQUEST['carid'];
		$ret.='<form class="report-form" id="report-disease">';
		$ret.='<div class="form-item" style="width:80%;float:left;">';
		$ret.='<label>รถ : </label><select name="carid" id="carid" class="form-select"><option value="">---เลือก---</option>';
		foreach ($this->__category('car.carname') as $k=>$car_name) $ret.='<option value="'.$k.'"'.($k==$carid?' selected="selected"':'').'>'.$car_name.'</option>';
		$ret.='</select>';
		$ret.='</div><div class="form-item" style="width:20%;float:right;"><input type="submit" class="button" value="ดูรายงาน" style="display:block;width:100%;font-size:1.3em;" /></div><br clear="all" />';
		$ret.='</form>';
		if (empty($carid)) return $ret.'กรุณาเลือกรถ';

		$stmt='SELECT carid, YEAR(`from_date`) `years`, DATE_FORMAT(`from_date`,"%Y-%m") `month`, COUNT(*) `times`, SUM(`kmto`-`kmfrom`) `kmtotal`
						FROM %calendar_car% car
							LEFT JOIN %calendar% c ON car.calid=c.id
						WHERE `carid`=:carid AND `kmfrom`>0 AND `kmto`>0
						GROUP BY `month`
						ORDER BY `month` ASC';
		$dbs=mydb::select($stmt,':carid',$carid);
		$ret.='<div id="chart_div" style="height:400px;"></div>';
		$data->title='รายงานจำนวนเที่ยว';
		$ghead[]='เดือน-ปี';
		$ghead[]='จำนวนเที่ยว';
		$ghead[]='ระยะทาง';
		$data->items[]=$ghead;

		$tables = new Table();
		$tables->caption='รายงานแยกตามพนักงาน';
		$tables->thead=array('เดือน-ปี','amt times'=>'จำนวนเที่ยว (เที่ยว)','amt kmtotal'=>'ระยะทาง (ก.ม.)');
		foreach ($dbs->items as $rs) {
			$tables->rows[]=array(sg_date($rs->month.'-01','ดดด ปปปป'),number_format($rs->times),number_format($rs->kmtotal));
			$timetotals+=$rs->times;
			$kmtotals+=$rs->kmtotal;
			unset($gdata);
			$gdata[]=sg_date($rs->month.'-01','ดด ปป');
			$gdata[]=intval($rs->times);
			$gdata[]=intval($rs->kmtotal);
			$data->items[]=$gdata;
		}
		$tables->tfoot[]=array('รวมทั้งสิ้น',number_format($timetotals),number_format($kmtotals));

		$ret .= $tables->build();

		//		$ret.=print_o($data,'$data');
		//		$ret.=print_o($dbs,'$dbs');

		$ret.='
		<style type="text/css">
		table.item td {text-align:center;}
		table.item>tfoot>tr>td {font-weight:bold;background:#DDDDDD;}
		</style>
		<script type="text/javascript">
		google.load("visualization", "1", {packages:["corechart"]});
		google.setOnLoadCallback(drawChart);
		function drawChart() {
			var data = google.visualization.arrayToDataTable('.json_encode($data->items).');
			var options = {title: "'.$data->title.'",
									hAxis: {title: "เดือน-ปี", titleTextStyle: {color: "black"}},
									series:[
										{targetAxisIndex:0},
										{targetAxisIndex:1},
									],
									vAxes:[
										{title: "จำนวนเที่ยว (เที่ยว)"}, // Left axis
										{title: "ระยะทาง (ก.ม.)"} // Right axis
									]
					};
			var chart = new google.visualization.ColumnChart(document.getElementById("chart_div"));
			chart.draw(data, options);
		}
		</script>';

		return $ret;
	}

	/**
	 * Get information by id
	 *
	 * @param Integer $id
	 * @return Record Set
	 */
	function __get_by_id($id) {
		$stmt='SELECT cr.*, c.owner, c.from_date, c.from_time, c.to_time, tcar.name carname, cr.resvby, tdepart.name departname, tobjectice.name objectivename, tdriver.name drivername
						FROM %calendar_car% cr
							LEFT JOIN %calendar% c ON c.id=cr.calid
							LEFT JOIN %tag% tcar ON tcar.tid=cr.carid
							LEFT JOIN %tag% tdepart ON tdepart.tid=cr.depart
							LEFT JOIN %tag% tobjectice ON tobjectice.tid=cr.objective
							LEFT JOIN %tag% tdriver ON tdriver.tid=cr.driver
						WHERE `calid`=:calid LIMIT 1';
		$rs=mydb::select($stmt,':calid',$id);
		return $rs;
	}

	/**
	 * Get category
	 *
	 * @param String $cat_group
	 * @param Array
	 */
	function __category($taggroup,$cat_id=NULL,$cat_name=NULL,$option=NULL) {
		$default=NULL;
		$ret=array();
		$dbs=mydb::select('SELECT * FROM %tag% WHERE `taggroup`=:taggroup',':taggroup',$taggroup);
		foreach ($dbs->items as $rs) {
			$ret[''.$rs->tid]=$rs->name;
			if (!$default && $rs->isdefault) $default=$rs->tid;
		}
		if ($option=='default') $ret=$default;
		return $ret;
	}

	/**
	 * Administrator main page
	 *
	 * @return String
	 */
	function _setting() {
		if (!user_access('administer calendar cars')) return message('error','Access denied');

		$post=(object)post('config');

		if ($post->title) property('calendar.car:title',$post->title);
		if ($post->detail) property('calendar.car:detail',$post->detail);

		$this->theme->title='Calendar car reservation Administrator';

		$property=$post ? property('calendar.car') : $this->property;

		$form->config->variable='config';
		$form->config->method='post';
		$form->config->action=url(q());

		$form->title->type='text';
		$form->title->label='ชื่อระบบงาน';
		$form->title->size=60;
		$form->title->value=htmlspecialchars($property['title']);

		$form->detail->type='textarea';
		$form->detail->label='คำอธิบาย';
		$form->detail->value=htmlspecialchars($property['detail']);

		$form->button->type='submit';
		$form->button->items->save=tr('Save');

		$ret .= theme('form','edit-config',$form);

		//		$ret.=print_o($post,'$post');
		//		$ret.=print_o($property,'$property');
		//		$ret.=print_o($vocabs,'$vocabs');

		return $ret;
	}

} // end of class calendar_car
?>
