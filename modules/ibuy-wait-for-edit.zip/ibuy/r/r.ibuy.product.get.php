<?php
/**
* iBuy Get Product Information
*
* @param Object $data
* @return Object $options
*/

$debug = true;

function r_ibuy_product_get($conditions, $options = '{}') {
	$defaults = '{debug: false, order: "t.`tpid` DESC", limit: 1, start: -1}';
	$options = sg_json_decode($options, $defaults);
	$debug = $options->debug;

	$result = NULL;

	$result = R::Model('paper.get', $conditions, $options);

	$stmt = 'SELECT
				p.*
			, o.`name` `shopName`
			, b.`flddata` `full_description`
			FROM %ibuy_product% p
				LEFT JOIN %topic% t USING(`tpid`)
				LEFT JOIN %db_org% o USING(`orgid`)
				LEFT JOIN %bigdata% b ON b.`keyname` = "ibuy" AND b.`keyid` = :tpid AND b.`fldname` = "description"
			WHERE p.`tpid` = :tpid
			LIMIT 1';

	$result->info = object_merge_recursive($result->info, mydb::clearprop(mydb::select($stmt, ':tpid', $result->tpid)));

	if ($debug) debugMsg($result, '$result');
	return $result;












	if (is_object($conditions)) ;
	else if (is_array($conditions)) $conditions = (object)$conditions;
	else {
		$tpid = $conditions;
		unset($conditions);
		$conditions->tpid = $tpid;
	}

	mydb::where('t.`type`="ibuy"');
	if ($conditions->tpid)
		mydb::where('t.`tpid`=:tpid', ':tpid', $conditions->tpid);

	if ($options->limit == 1) {
		mydb::value('$LIMIT$','LIMIT 1');
		mydb::value('$ORDER$','');
	} else if ($options->limit == '*') {
		mydb::value('$LIMIT$','');
		mydb::value('$ORDER$', 'ORDER BY '.$options->order);
	} else {
		mydb::value('$LIMIT$','LIMIT '.$options->limit);
		mydb::value('$ORDER$', 'ORDER BY '.$options->order);
	}

	$stmt = 'SELECT t.`tpid`, t.`revid`, t.`title`, p.*, r.`body`
					FROM %topic% t
						LEFT JOIN %ibuy_product% p USING(`tpid`)
						LEFT JOIN %topic_revisions% r USING(`revid`)
					%WHERE%
					$ORDER$
					$LIMIT$
					';

	$dbs = mydb::select($stmt);

	if ($debug) debugMsg(mydb()->_query);

	if ($options->limit == 1) {
		$info = $dbs;
		$result->tpid = $info->tpid;
		$result->title = $info->title;
		$result->RIGHT = NULL;
		$result->info = NULL;
		$result->officers = NULL;

		$info->isAdmin = is_admin('ibuy');
		$info->isOrgAdmin = false;
		$info->isOfficer = false;
		$info->isOwner = false;
		$info->isEdit = false;
		$info->isTrainer = false;
		$result->officers = array();

		$stmt = 'SELECT o.* FROM %org_officer% o LEFT JOIN %users% u USING(`uid`) WHERE o.`orgid` = :orgid AND u.`status` = "enable"';
		$dbs = mydb::select($stmt, ':orgid', $info->orgid);
		foreach ($dbs->items as $item) {
			$result->officers[$item->uid] = strtoupper($item->membership);
		}

		if (i()->ok) {
			$info->isOfficer = array_key_exists(i()->uid, $info->officers) && in_array($info->officers[i()->uid],array('ADMIN','OFFICER'));
			$info->isOrgAdmin = $info->isOfficer && $info->officers[i()->uid]=='ADMIN';
			$info->isOwner = i()->uid == $info->uid || ($info->isOfficer && in_array($info->officers[i()->uid],array('ADMIN','OFFICER')));
			$info->isEdit = $info->isAdmin || $info->isOwner;
			$info->isTrainer = $info->officers[i()->uid] == 'TRAINER';
		}

		$result->info = $info;

		mydb::clearprop($result->info);

		$result->photo = NULL;

		$stmt = 'SELECT * FROM %topic_files% WHERE `tpid` = :tpid AND `type` = "photo" AND `cid` = 0';
		$result->photo = mydb::select($stmt, ':tpid', $result->tpid)->items;
		foreach ($result->photo as $key => $rs) {
			$photo = model::get_photo_property($rs->file);
			$result->photo[$key]->prop = $photo;
		}

	} else {
		$result = $dbs->items;
	}

	return $result;
}
?>