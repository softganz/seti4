<?php
/**
* ibuy_product class for product management
*
* @package ibuy
* @subpackage ibuy_product
* @copyright Copyright (c) 2000-present , The SoftGanz Group By Panumas Nontapan
* @author Panumas Nontapan <webmaster@softganz.com> , http://www.softganz.com
* @created 2009-06-22
* @modify 2010-02-05
* ============================================
* This program is free software. You can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License.
* ============================================
*/

function ibuy_product($self) {
	location('ibuy');
}
?>