<?php

function _ibuy_cleantitle() {
	$ret='<h3>Clean Title</h3>';

	return $ret;
}
?>