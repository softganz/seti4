<?php
/**
 * Create new product information
 *
 * @return String
 */
function ibuy_product_post($self) {
	location('paper/post/ibuy');
}
?>