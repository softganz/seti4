<?php
function ibuy_user_smf($self) {
	$ret='<h3>SMF User</h3>';
	return $ret;
}
?>