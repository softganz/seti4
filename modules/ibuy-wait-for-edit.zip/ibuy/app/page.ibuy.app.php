<?php
/**
* Module Method
* Created 2019-11-01
* Modify  2019-11-01
*
* @param Object $self
* @param Int $var
* @return String
*/

$debug = true;

function ibuy_app($self) {
	$ret = '';
	$ret .= 'Welcome to app';
	return $ret;
}
?>