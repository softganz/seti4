<?php
function ibuy_app_consumer($self,$psnid) {
	R::View('ibuy.toolbar',$self,'เครือข่ายผู้ผู้บริโภค','app.hatyaigogreen');

	return $ret;
}
?>