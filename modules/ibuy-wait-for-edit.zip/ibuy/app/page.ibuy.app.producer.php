<?php
function ibuy_app_producer($self,$psnid) {
	R::View('ibuy.toolbar',$self,'เครือข่ายผู้ผลิต','app.hatyaigogreen');

	return $ret;
}
?>