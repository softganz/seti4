<?php
function ibuy_app_supporter($self,$psnid) {
	R::View('ibuy.toolbar',$self,'เครือข่ายผู้สนับสนุน','app.hatyaigogreen');

	return $ret;
}
?>