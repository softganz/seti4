<?php
function ibuy_hatyaigogreen($self) {
	$ret.='<h2>Hatyai Go Green Home Page</h2>';
	return $ret;
}
?>