<?php
function ibuy_hatyaigogreen_app($self) {
	R::View('ibuy.hatyaigogreen.toolbar',$self,'HATYAI GO GREEN');
	$ret.='<h2>Hatyai Go Green App</h2>';
	return $ret;
}
?>