<?php
/**
* Green Smile Supporter
* Created 2019-10-27
* Modify  2019-10-27
*
* @param Object $self
* @param Int $var
* @return String
*/

$debug = true;

function ibuy_green_supporter($self) {
	$ret = '';

	$ret .= '<header class="header"><h3>ผู้สนับสนุน</h3></header>';
	$ret .= '<header class="header"><h3>ผู้สนับสนุน</h3></header>';
	$ret .= '<header class="header"><h3>ผู้สนับสนุน</h3></header>';
	$ret .= '<header class="header"><h3>ผู้สนับสนุน</h3></header>';
	$ret .= '<header class="header"><h3>ผู้สนับสนุน</h3></header>';
	return $ret;
}
?>