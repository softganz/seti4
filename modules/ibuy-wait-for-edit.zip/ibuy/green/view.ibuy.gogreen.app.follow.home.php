<?php
/**
* GoGreen Spp Shop Goods
*
* @param Object $self
* @param Int $tpid
* @return String
*/

$debug = true;

function view_ibuy_green_app_follow_home() {
	$ret = '';
	$ret .= 'FOLLOW';
	return $ret;
}
?>