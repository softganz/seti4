<?php
/**
* GoGreen Spp Shop Goods
*
* @param Object $self
* @param Int $tpid
* @return String
*/

$debug = true;

function view_ibuy_green_app_category_home() {
	$ret = '';
	$ret .= 'CATEGORY';
	return $ret;
}
?>